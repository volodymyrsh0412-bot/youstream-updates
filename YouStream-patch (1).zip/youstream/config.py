"""Налаштування (data/settings.json) і невеликий JSON-сховищний хелпер."""
import json
import os
import threading

from . import paths

DEFAULTS = {
    "speech_mode": "screenreader",   # screenreader | sapi | off
    "audio_lang": "orig",            # мова звуку відео з кількома доріжками: orig - оригінал | uk - українська, якщо є
    "video_proxy": True,             # відео качається шматками через локальний проксі (без обмеження швидкості)
    "video_hwdec": "auto",           # апаратне декодування відео: auto | copy | no
    "audio_quality": "best",         # best | medium | low
    "seek_small": 10,
    "seek_big": 60,
    "volume": 80,
    "speed": 1.0,
    "autoplay_next": True,
    "resume_position": True,
    "repeat": "off",                 # off | all | one
    "shuffle": False,
    "results_count": 25,             # 25..500 з кроком 25
    "eq_preset": "normal",           # ключ з youstream.equalizer.PRESETS
    "emoji_mode": "symbol",          # емодзі: off - прибрати | symbol - показувати символами | words - словами
    "verbosity": "full",             # детальність озвучення: full | normal | minimal
    "prefer_ad": True,               # надавати перевагу доріжці з аудіодескрипцією, якщо вона є
    "theme": "system",               # вигляд: system - як у Windows | light | dark
    "play_mode": "audio",            # поточний режим: audio | video
    "mode_start": "ask",             # при запуску: ask - питати | audio - завжди аудіо | video - завжди відео
    "video_height": "480",           # якість відео при перегляді: 1080 | 720 | 480 | 360 | best
    "offer_resume": True,            # (застаріло) див. startup_resume
    "startup_resume": "ask",         # ask - питати | auto - продовжити саме | off - нічого
    "category_hint": "українською",  # додається до пошуку в розділах «Головної»
    "show_thumbnails": True,         # мініатюри відео у списках (для зрячих)
    "dl_audio": "mp3:best",          # F3: mp3:best | mp3:192 | mp3:128 | m4a
    "dl_video_height": 1080,         # F4: 360 | 480 | 720 | 1080 | 1440 | 2160
    "last_dl_spec": "mp3:best",     # остання вибрана якість у вікні Ctrl+D
    "download_dir": "",
    "cookies_mode": "none",          # none | browser | file
    "cookies_browser": "firefox",
    "cookies_file": "",
    "voice_lang": "uk-UA",
    "home_fallback_query": "популярне українською",
    "audio_device": "auto",          # пристрій виводу звуку: auto або назва з mpv (wasapi/...)
    "balance": 0,                    # баланс лівого й правого динаміка: -100 (ліворуч) .. 100 (праворуч)
    "subs_on": False,                # озвучувати субтитри відео
    "sub_lang": "uk",                # мова субтитрів: uk | en | ru | pl | de | orig (як в оригіналі)
    "sub_engine": "sapi",            # sapi - голос Windows (гучність регулюється) | screenreader
    "sub_voice": "",                 # назва голосу SAPI ("" - сам обере українській, якщо є)
    "sub_rate": 2,                   # швидкість голосу субтитрів -10..10
    "sub_mix": 0,                    # баланс -100..100: плюс - голосніші субтитри, мінус - голосніше відео
    "sub_save": "txt",               # зберігати субтитри в папку завантажень: none | txt | srt | both
    "sub_show": True,                # показувати субтитри на картинці (відеорежим)
    "desc_mode": "window",           # опис відео: window - окреме вікно (читати й копіювати) | speak - озвучити
    "notify_upcoming": True,         # озвучувати, коли прем'єра чи трансляція стане доступною
    "list_lang": "",                 # приховане: "" - автоматично (українська, час публікації добирається окремо); off - вимкнути
    "keys": {},                      # перепризначені клавіші {action: "Ctrl+X"}
}

_lock = threading.RLock()

COUNT_CHOICES = list(range(25, 501, 25))
# Комбінація «кількість по колу» перебирає саме ці значення
COUNT_CYCLE = (25, 50, 100, 150, 250, 500)


def next_count(current: int, direction: int = 1) -> int:
    """Наступне (direction=1) або попереднє (-1) значення з COUNT_CYCLE по колу."""
    cur = normalize_count(current)
    if direction >= 0:
        for n in COUNT_CYCLE:
            if n > cur:
                return n
        return COUNT_CYCLE[0]
    for n in reversed(COUNT_CYCLE):
        if n < cur:
            return n
    return COUNT_CYCLE[-1]


def normalize_count(v) -> int:
    """Кількість елементів у списку: ціле від 25 до 500, кратне 25."""
    try:
        v = int(v)
    except (TypeError, ValueError):
        return 25
    v = max(25, min(500, v))
    return int(round(v / 25.0)) * 25


def read_json(path: str, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path: str, data) -> None:
    tmp = path + ".tmp"
    with _lock:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)


class Settings:
    def __init__(self, path: str | None = None):
        self.path = path or os.path.join(paths.data_dir(), "settings.json")
        self.data = dict(DEFAULTS)
        self.data["keys"] = {}
        loaded = read_json(self.path, {})
        if isinstance(loaded, dict):
            for k, v in loaded.items():
                if k in DEFAULTS:
                    self.data[k] = v

    def __getitem__(self, key):
        v = self.data.get(key, DEFAULTS.get(key))
        if key == "startup_resume" and "startup_resume" not in self.data and not self.data.get("offer_resume", True):
            return "off"
        if key == "results_count":
            return normalize_count(v)
        return v

    def __setitem__(self, key, value):
        self.data[key] = value

    def save(self) -> None:
        write_json(self.path, self.data)

    @property
    def download_dir(self) -> str:
        d = self.data.get("download_dir") or paths.default_downloads_dir()
        os.makedirs(d, exist_ok=True)
        return d

    def has_account(self) -> bool:
        mode = self["cookies_mode"]
        if mode == "browser":
            return bool(self["cookies_browser"])
        if mode == "file":
            return os.path.isfile(self["cookies_file"] or "")
        return False


DEVELOPER_DEFAULT = {"name": "Volodymyr Shubynets", "email": "volodymyrsh0412@gmail.com"}


def developer_info() -> dict:
    """Ім'я та пошта розробника з data/developer.json. Файл створюється при першому запуску;
    його можна змінити в Блокноті - перезбирати програму не потрібно."""
    path = os.path.join(paths.data_dir(), "developer.json")
    loaded = read_json(path, None)
    info = dict(DEVELOPER_DEFAULT)
    if isinstance(loaded, dict):
        for k in ("name", "email"):
            if isinstance(loaded.get(k), str) and loaded[k].strip():
                info[k] = loaded[k].strip()
    else:
        try:
            write_json(path, info)
        except OSError:
            pass
    return info
