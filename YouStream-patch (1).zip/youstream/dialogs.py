"""Діалоги: налаштування, клавіші, довідка. Лише стандартні елементи wx (зручно для зчитувачів)."""
import threading

import wx

from . import keys as K
from . import youtube
from .config import COUNT_CHOICES, normalize_count
from .downloader import DOWNLOAD_CHOICES, parse_spec

SPEECH_MODES = [("screenreader", "Через зчитувач екрана (NVDA, JAWS, Narrator)"),
                ("sapi", "Через голос Windows (SAPI)"),
                ("off", "Вимкнено")]
QUALITIES = [("best", "Найкраща"), ("medium", "Середня (економить трафік)"), ("low", "Низька")]
COOKIE_MODES = [("none", "Без акаунта"), ("browser", "Взяти з браузера"), ("file", "З файлу cookies.txt")]
BROWSERS = ["firefox", "edge", "chrome", "brave", "opera", "vivaldi", "chromium"]
VIDEO_HEIGHTS = [("1080", "1080p"), ("720", "720p"), ("480", "480p"), ("360", "360p"),
                 ("best", "Найкраща (може гальмувати на слабких комп'ютерах)")]
AUDIO_LANGS = [("orig", "Оригінальна (як у автора відео)"), ("uk", "Українська, якщо є дубляж"),
               ("en", "Англійська, якщо є"), ("ru", "Російська, якщо є"), ("pl", "Польська, якщо є"),
               ("de", "Німецька, якщо є"), ("fr", "Французька, якщо є"), ("es", "Іспанська, якщо є")]
SUB_LANGS = [("uk", "Автоматично українською (переклад YouTube, якщо готових немає)"),
             ("orig", "Мова оригіналу відео")]
SUB_SAVES = [("none", "Не зберігати"), ("txt", "Лише текст (TXT)"),
             ("srt", "З часом (SRT)"), ("both", "Обидва формати (TXT і SRT)")]
EMOJI_MODES = [("symbol", "Показувати символами (їх видно, озвучує зчитувач екрана)"),
               ("words", "Замінювати словами (чути завжди, символів не видно)"),
               ("off", "Прибирати")]
VERBOSITIES = [("full", "Докладно (все)"), ("normal", "Звичайно (без дрібних пояснень)"),
               ("minimal", "Коротко (лише головне)")]
DESC_MODES = [("window", "Показувати в окремому вікні (можна прочитати й скопіювати)"),
              ("speak", "Озвучувати")]
SUB_ENGINES = [("sapi", "Голос Windows (SAPI): гучність субтитрів регулюється балансом"),
               ("screenreader", "Зчитувач екрана (гучність голосу не регулюється)")]
HWDECS = [("auto", "Авто"), ("copy", "Копіювання (стабільніше на старих відеокартах)"),
          ("no", "Вимкнено (програмне, найповільніше)")]
MODE_STARTS = [("ask", "Питати при вході: аудіорежим чи відеорежим"),
               ("audio", "Завжди аудіорежим (відео вмикається лише клавішами Ctrl+Shift+V)"),
               ("video", "Завжди відеорежим (аудіо вмикається лише клавішами Ctrl+Shift+V)")]
from .theme import THEMES

VOICE_LANGS = [("uk-UA", "Українська"), ("en-US", "English"), ("pl-PL", "Polski"),
               ("de-DE", "Deutsch"), ("ru-RU", "Русский")]


def _idx(pairs, value, default=0):
    for i, p in enumerate(pairs):
        if (p[0] if isinstance(p, tuple) else p) == value:
            return i
    return default


class SettingsDialog(wx.Dialog):
    def __init__(self, parent, settings, keymap, on_update_engine=None):
        super().__init__(parent, title="Налаштування", style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.s, self.keymap, self.on_update_engine = settings, keymap, on_update_engine
        self.scroll = wx.ScrolledWindow(self, style=wx.VSCROLL)
        self.scroll.SetScrollRate(0, 12)
        grid = wx.BoxSizer(wx.VERTICAL)
        box = self.scroll

        # Підпис ЗАВЖДИ над елементом і створюється безпосередньо перед ним: так порядок
        # табуляції, зчитувач і вигляд на екрані збігаються.
        def row(label, make):
            grid.Add(wx.StaticText(box, label=label), 0, wx.TOP, 8)
            ctrl = make(box)
            grid.Add(ctrl, 0, wx.EXPAND | wx.TOP, 2)
            return ctrl

        def check(label, value):
            c = wx.CheckBox(box, label=label)
            c.SetValue(bool(value))
            grid.Add(c, 0, wx.TOP, 10)
            return c

        def choice(options, sel):
            def mk(p):
                c = wx.Choice(p, choices=options)
                c.SetSelection(sel)
                return c
            return mk

        self.speech = row("Озвучення подій:", choice([p[1] for p in SPEECH_MODES], _idx(SPEECH_MODES, settings["speech_mode"])))
        self.quality = row("Якість звуку:", choice([p[1] for p in QUALITIES], _idx(QUALITIES, settings["audio_quality"])))
        self.alang = row("Мова звуку відео з кількома доріжками:",
                         choice([p[1] for p in AUDIO_LANGS], _idx(AUDIO_LANGS, str(settings["audio_lang"]))))
        self.desc_mode = row("Опис відео:",
                             choice([p[1] for p in DESC_MODES], _idx(DESC_MODES, settings["desc_mode"])))
        self.sub_lang = row("Мова субтитрів для озвучення:",
                            choice([p[1] for p in SUB_LANGS], _idx(SUB_LANGS, settings["sub_lang"])))
        self.sub_engine = row("Чим озвучувати субтитри:",
                              choice([p[1] for p in SUB_ENGINES], _idx(SUB_ENGINES, settings["sub_engine"])))
        from .subvoice import list_voices
        self._voice_names = [d for d, _a in list_voices()]
        vsel = self._voice_names.index(settings["sub_voice"]) + 1 if settings["sub_voice"] in self._voice_names else 0
        self.sub_voice = row("Голос субтитрів (SAPI):",
                             choice(["Автоматично (український, якщо встановлено)"] + self._voice_names, vsel))
        self.sub_rate = row("Швидкість голосу субтитрів (від -10 до 10):",
                            lambda p: wx.SpinCtrl(p, min=-10, max=10, initial=int(settings["sub_rate"])))
        from .subtitles import save_mode
        self.sub_save = row("Зберігати субтитри в папку завантажень (підпапка «Субтитри»):",
                            choice([p[1] for p in SUB_SAVES], _idx(SUB_SAVES, save_mode(settings["sub_save"]))))
        self.sub_show = check("Показувати субтитри на картинці у відеорежимі", settings["sub_show"])
        self.notify_up = check("Озвучувати, коли прем'єра чи трансляція, що ще не почалася, стане доступною",
                               settings["notify_upcoming"])
        self.vproxy = check("Швидке завантаження відео шматками (вимкніть, якщо відео не стартує)", settings["video_proxy"])
        self.hwdec = row("Апаратне декодування відео:",
                         choice([p[1] for p in HWDECS], _idx(HWDECS, settings["video_hwdec"])))
        self.emoji = row("Емодзі в назвах, іменах авторів і коментарях:",
                         choice([p[1] for p in EMOJI_MODES], _idx(EMOJI_MODES, settings["emoji_mode"])))
        self.verbosity = row("Детальність озвучення службових повідомлень:",
                             choice([p[1] for p in VERBOSITIES], _idx(VERBOSITIES, settings["verbosity"])))
        self.prefer_ad = check("Надавати перевагу доріжці з аудіодескрипцією (опис сцен для незрячих), якщо вона є",
                               settings["prefer_ad"])
        self.theme = row("Вигляд вікна (тема):",
                         choice([p[1] for p in THEMES], _idx(THEMES, settings["theme"])))
        self.mode_start = row("Режим програми при запуску:",
                              choice([p[1] for p in MODE_STARTS], _idx(MODE_STARTS, settings["mode_start"])))
        self.vheight = row("Якість відео при перегляді:",
                           choice([p[1] for p in VIDEO_HEIGHTS], _idx(VIDEO_HEIGHTS, str(settings["video_height"]), 1)))
        self.seek_small = row("Малий крок перемотки, секунд:", lambda p: wx.SpinCtrl(p, min=1, max=300, initial=int(settings["seek_small"])))
        self.seek_big = row("Великий крок перемотки, секунд:", lambda p: wx.SpinCtrl(p, min=5, max=1800, initial=int(settings["seek_big"])))
        n = normalize_count(settings["results_count"])
        self.count = row("Кількість елементів у списках:", choice([str(c) for c in COUNT_CHOICES], COUNT_CHOICES.index(n)))
        self.hint = row("Слово до пошуку в розділах Головної (мова, наприклад «українською»):",
                        lambda p: wx.TextCtrl(p, value=settings["category_hint"] or ""))
        self.thumbs = check("Показувати мініатюри відео у списках (зручно зрячим)", settings["show_thumbnails"])
        self._audio_specs = [c for c in DOWNLOAD_CHOICES if parse_spec(c[0])[0] != "mp4"]
        self._video_specs = [c for c in DOWNLOAD_CHOICES if parse_spec(c[0])[0] == "mp4"]
        self.dl_audio = row("Клавіша F3 завантажує аудіо як:",
                            choice([c[1] for c in self._audio_specs], _idx(self._audio_specs, settings["dl_audio"])))
        self.dl_video = row("Клавіша F4 завантажує відео до:",
                            choice([c[1] for c in self._video_specs],
                                   _idx(self._video_specs, "mp4:%s" % settings["dl_video_height"], 2)))
        self._startup = (("ask", "Питати, чи продовжити останнє"),
                         ("auto", "Продовжувати саме, без запитань"),
                         ("off", "Нічого не робити, почати з чистого аркуша"))
        self.startup = row("Під час запуску програми:",
                           choice([p[1] for p in self._startup], _idx(self._startup, settings["startup_resume"])))
        self.resume = check("Запам'ятовувати місце, де я зупинився в кожному відео, і продовжувати з нього",
                            settings["resume_position"])
        self.autoplay = check("Автоматично грати наступний трек", settings["autoplay_next"])
        self.dldir = row("Папка завантажень:", lambda p: wx.TextCtrl(p, value=settings.download_dir))
        b = wx.Button(box, label="Обрати папку завантажень...")
        b.Bind(wx.EVT_BUTTON, self._pick_dir)
        grid.Add(b, 0, wx.TOP, 4)
        self.cmode = row("Акаунт YouTube:", choice([p[1] for p in COOKIE_MODES], _idx(COOKIE_MODES, settings["cookies_mode"])))
        self.cbrowser = row("Браузер, у якому ви увійшли в YouTube:", choice(BROWSERS, _idx(BROWSERS, settings["cookies_browser"])))
        self.cfile = row("Файл cookies.txt:", lambda p: wx.TextCtrl(p, value=settings["cookies_file"] or ""))
        b2 = wx.Button(box, label="Обрати файл cookies.txt...")
        b2.Bind(wx.EVT_BUTTON, self._pick_cookie)
        grid.Add(b2, 0, wx.TOP, 4)
        self.vlang = row("Мова голосового пошуку:", choice([p[1] for p in VOICE_LANGS], _idx(VOICE_LANGS, settings["voice_lang"])))
        box.SetSizer(grid)

        btns = wx.BoxSizer(wx.HORIZONTAL)
        kb = wx.Button(self, label="Клавіші...")
        kb.Bind(wx.EVT_BUTTON, lambda e: KeysDialog(self, self.keymap).ShowModal())
        btns.Add(kb, 0, wx.RIGHT, 8)
        if on_update_engine:
            ub = wx.Button(self, label="Оновити рушій YouTube (yt-dlp)")
            ub.Bind(wx.EVT_BUTTON, lambda e: self.on_update_engine())
            btns.Add(ub, 0, wx.RIGHT, 8)
        btns.AddStretchSpacer()
        ok = wx.Button(self, wx.ID_OK, "Зберегти")
        ok.SetDefault()
        btns.Add(ok, 0, wx.RIGHT, 8)
        btns.Add(wx.Button(self, wx.ID_CANCEL, "Скасувати"))

        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(self.scroll, 1, wx.ALL | wx.EXPAND, 12)
        root.Add(btns, 0, wx.ALL | wx.EXPAND, 12)
        self.SetSizer(root)
        self.SetSize((620, 600))
        self.SetMinSize((480, 360))
        self.speech.SetFocus()

    def _pick_dir(self, _):
        with wx.DirDialog(self, "Папка завантажень", self.dldir.GetValue()) as d:
            if d.ShowModal() == wx.ID_OK:
                self.dldir.SetValue(d.GetPath())

    def _pick_cookie(self, _):
        with wx.FileDialog(self, "Файл cookies.txt", wildcard="*.txt|*.txt|Усі файли|*.*",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as d:
            if d.ShowModal() == wx.ID_OK:
                self.cfile.SetValue(d.GetPath())
                self.cmode.SetSelection(_idx(COOKIE_MODES, "file"))

    def apply(self):
        s = self.s
        s["speech_mode"] = SPEECH_MODES[self.speech.GetSelection()][0]
        s["audio_quality"] = QUALITIES[self.quality.GetSelection()][0]
        s["audio_lang"] = AUDIO_LANGS[max(0, self.alang.GetSelection())][0]
        s["desc_mode"] = DESC_MODES[max(0, self.desc_mode.GetSelection())][0]
        s["sub_lang"] = SUB_LANGS[max(0, self.sub_lang.GetSelection())][0]
        s["sub_engine"] = SUB_ENGINES[max(0, self.sub_engine.GetSelection())][0]
        vi = self.sub_voice.GetSelection()
        s["sub_voice"] = self._voice_names[vi - 1] if 0 < vi <= len(self._voice_names) else ""
        s["sub_rate"] = self.sub_rate.GetValue()
        s["sub_save"] = SUB_SAVES[max(0, self.sub_save.GetSelection())][0]
        s["sub_show"] = self.sub_show.GetValue()
        s["notify_upcoming"] = self.notify_up.GetValue()
        s["video_proxy"] = self.vproxy.GetValue()
        s["video_hwdec"] = HWDECS[max(0, self.hwdec.GetSelection())][0]
        s["emoji_mode"] = EMOJI_MODES[max(0, self.emoji.GetSelection())][0]
        s["verbosity"] = VERBOSITIES[max(0, self.verbosity.GetSelection())][0]
        s["prefer_ad"] = self.prefer_ad.GetValue()
        s["theme"] = THEMES[max(0, self.theme.GetSelection())][0]
        s["mode_start"] = MODE_STARTS[max(0, self.mode_start.GetSelection())][0]
        s["video_height"] = VIDEO_HEIGHTS[max(0, self.vheight.GetSelection())][0]
        s["seek_small"] = self.seek_small.GetValue()
        s["seek_big"] = self.seek_big.GetValue()
        s["results_count"] = COUNT_CHOICES[max(0, self.count.GetSelection())]
        s["category_hint"] = self.hint.GetValue().strip()
        s["show_thumbnails"] = self.thumbs.GetValue()
        s["dl_audio"] = self._audio_specs[max(0, self.dl_audio.GetSelection())][0]
        s["dl_video_height"] = int(parse_spec(self._video_specs[max(0, self.dl_video.GetSelection())][0])[1])
        s["startup_resume"] = self._startup[max(0, self.startup.GetSelection())][0]
        s["autoplay_next"] = self.autoplay.GetValue()
        s["resume_position"] = self.resume.GetValue()
        s["download_dir"] = self.dldir.GetValue().strip()
        s["cookies_mode"] = COOKIE_MODES[self.cmode.GetSelection()][0]
        s["cookies_browser"] = BROWSERS[self.cbrowser.GetSelection()]
        s["cookies_file"] = self.cfile.GetValue().strip()
        s["voice_lang"] = VOICE_LANGS[self.vlang.GetSelection()][0]
        s["keys"] = self.keymap.overrides()
        s.save()


class CaptureDialog(wx.Dialog):
    """Ловить натискання комбінації. Escape - скасувати."""
    FORBIDDEN = {"Tab", "Shift+Tab", "Enter", "Ctrl+Tab", "Ctrl+Shift+Tab"}

    def __init__(self, parent, action_label):
        super().__init__(parent, title="Нова клавіша")
        self.combo = None
        txt = wx.StaticText(self, label="Натисніть нову комбінацію клавіш для дії «%s». "
                                        "Escape - скасувати." % action_label)
        txt.Wrap(380)
        s = wx.BoxSizer(wx.VERTICAL)
        s.Add(txt, 0, wx.ALL, 16)
        self.SetSizerAndFit(s)
        self.Bind(wx.EVT_CHAR_HOOK, self._on_key)

    def _on_key(self, e):
        combo = K.event_to_combo(e.GetKeyCode(), e.ControlDown(), e.AltDown(), e.ShiftDown(),
                                 e.GetUnicodeKey())
        if combo is None:
            return
        if combo == "Escape":
            self.EndModal(wx.ID_CANCEL)
            return
        if combo in self.FORBIDDEN:
            wx.Bell()
            return
        self.combo = combo
        self.EndModal(wx.ID_OK)


class KeysDialog(wx.Dialog):
    def __init__(self, parent, keymap):
        super().__init__(parent, title="Клавіші", size=(640, 520), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.km = keymap
        # Один стовпчик: зчитувач каже рядок один раз («Швидкість +: Ctrl+Shift+Стрілка вгору, 14 з 47»),
        # без назв стовпців і групи, що повторювалися б на кожному рядку.
        self.lc = wx.ListBox(self, style=wx.LB_SINGLE)
        self.lc.SetName("Клавіші")
        btns = wx.BoxSizer(wx.HORIZONTAL)
        for label, handler in (("Змінити...", self.on_change), ("Скинути вибрану", self.on_reset_one),
                               ("Скинути всі", self.on_reset_all)):
            b = wx.Button(self, label=label)
            b.Bind(wx.EVT_BUTTON, handler)
            btns.Add(b, 0, wx.RIGHT, 8)
        btns.AddStretchSpacer()
        close = wx.Button(self, wx.ID_CLOSE, "Закрити")
        close.Bind(wx.EVT_BUTTON, lambda e: self.EndModal(wx.ID_OK))
        btns.Add(close)
        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(wx.StaticText(self, label="Усі клавіші діють лише у вікні YouStream. "
                                           "Виберіть дію і натисніть Enter, щоб змінити клавішу."),
                 0, wx.ALL, 10)
        root.Add(self.lc, 1, wx.ALL | wx.EXPAND, 10)
        root.Add(btns, 0, wx.ALL | wx.EXPAND, 10)
        self.SetSizer(root)
        self.lc.Bind(wx.EVT_LISTBOX_DCLICK, self.on_change)
        self.lc.Bind(wx.EVT_KEY_DOWN, self._on_lc_key)
        self.fill()
        if self.lc.GetCount():
            self.lc.SetSelection(0)
        self.lc.SetFocus()

    def _on_lc_key(self, e):
        if e.GetKeyCode() in (wx.WXK_RETURN, wx.WXK_NUMPAD_ENTER):
            self.on_change()
        else:
            e.Skip()

    def fill(self, keep: int | None = None):
        rows = ["%s: %s" % (label, K.display_combo(self.km.key_of(aid)) if self.km.key_of(aid) else "не призначено")
                for aid, label, _d, _g in K.ACTIONS]
        self.lc.Set(rows)
        if keep is not None and keep < self.lc.GetCount():
            self.lc.SetSelection(keep)

    def _sel(self):
        i = self.lc.GetSelection()
        return i, (K.ACTION_IDS[i] if i >= 0 else None)

    def on_change(self, _e=None):
        i, aid = self._sel()
        if aid is None:
            return
        dlg = CaptureDialog(self, K.LABELS[aid])
        if dlg.ShowModal() == wx.ID_OK and dlg.combo:
            other = self.km.conflict(aid, dlg.combo)
            steal = False
            if other:
                r = wx.MessageBox("Ця клавіша вже призначена дії «%s». Перепризначити?" % K.LABELS[other],
                                  "Конфлікт клавіш", wx.YES_NO | wx.ICON_QUESTION, self)
                if r != wx.YES:
                    dlg.Destroy()
                    return
                steal = True
            self.km.set(aid, dlg.combo, steal=steal)
            self.fill(i)
        dlg.Destroy()

    def on_reset_one(self, _e):
        i, aid = self._sel()
        if aid:
            self.km.reset(aid)
            self.fill(i)

    def on_reset_all(self, _e):
        if wx.MessageBox("Скинути всі клавіші до стандартних?", "Підтвердження",
                         wx.YES_NO | wx.ICON_QUESTION, self) == wx.YES:
            self.km.reset()
            self.fill(0)


def show_help(parent, keymap):
    dlg = wx.Dialog(parent, title="Клавіші YouStream", size=(620, 560),
                    style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
    lines, group = [], None
    for aid, label, _d, g in K.ACTIONS:
        if g != group:
            group = g
            lines.append("")
            lines.append(g.upper())
        key = keymap.key_of(aid)
        lines.append("%s: %s" % (label, K.display_combo(key) if key else "не призначено"))
    lines += ["", "ЗАГАЛЬНЕ",
              "Enter: обрати, відкрити або відтворити (також натискає кнопки)",
              "Пробіл: натискає кнопку (як скрізь у Windows). Пауза / відтворення: Escape",
              "Клавіша Menu або Shift+F10: контекстне меню дій для елемента (Backspace або Escape - закрити меню)",
              "Ctrl+Tab / Ctrl+Shift+Tab: наступна / попередня вкладка",
              "Стрілки вправо-вліво на вкладках: наступна / попередня вкладка, Enter - до вмісту вкладки; внизу ті самі стрілки - між кнопками",
              "Tab / Shift+Tab: перехід лише між верхом (вкладки) і низом (голосовий пошук і панель керування)"]
    tc = wx.TextCtrl(dlg, value="\n".join(lines).strip(), style=wx.TE_MULTILINE | wx.TE_READONLY)
    close = wx.Button(dlg, wx.ID_OK, "Закрити")
    s = wx.BoxSizer(wx.VERTICAL)
    s.Add(tc, 1, wx.ALL | wx.EXPAND, 10)
    s.Add(close, 0, wx.ALL | wx.ALIGN_RIGHT, 10)
    dlg.SetSizer(s)
    tc.SetFocus()
    dlg.ShowModal()
    dlg.Destroy()


class ActionMenuDialog(wx.Dialog):
    """Меню дій для елемента: список; Enter - вибрати, Backspace або Escape - закрити."""

    def __init__(self, parent, labels, title="Дії"):
        super().__init__(parent, title=title, size=(480, 440), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.choice = -1
        self.lb = wx.ListBox(self, choices=labels, style=wx.LB_SINGLE)
        self.lb.SetName("Дії")
        if labels:
            self.lb.SetSelection(0)
        s = wx.BoxSizer(wx.VERTICAL)
        s.Add(self.lb, 1, wx.ALL | wx.EXPAND, 10)
        s.Add(wx.StaticText(self, label="Enter - вибрати. Backspace або Escape - закрити меню."),
              0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
        self.SetSizer(s)
        self.lb.Bind(wx.EVT_LISTBOX_DCLICK, self._ok)
        self.Bind(wx.EVT_CHAR_HOOK, self._on_key)
        self.lb.SetFocus()

    def _on_key(self, e):
        k = e.GetKeyCode()
        if k in (wx.WXK_BACK, wx.WXK_ESCAPE):
            self.EndModal(wx.ID_CANCEL)
        elif k in (wx.WXK_RETURN, wx.WXK_NUMPAD_ENTER):
            self._ok()
        else:
            e.Skip()

    def _ok(self, _e=None):
        i = self.lb.GetSelection()
        if i >= 0:
            self.choice = i
            self.EndModal(wx.ID_OK)


class CommentsDialog(wx.Dialog):
    """Читання коментарів і написання свого. Лише стандартні елементи (зручно для зчитувачів)."""

    def __init__(self, parent, frame, item):
        super().__init__(parent, title="Коментарі", size=(720, 560),
                         style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.frame, self.item = frame, item
        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(wx.StaticText(self, label="Коментарі до: %s" % item.title), 0, wx.ALL, 10)
        root.Add(wx.StaticText(self, label="Список коментарів:"), 0, wx.LEFT | wx.RIGHT, 10)
        self.lb = wx.ListBox(self, choices=["Завантаження коментарів..."])
        self.lb.SetName("Список коментарів")
        root.Add(self.lb, 1, wx.ALL | wx.EXPAND, 10)
        root.Add(wx.StaticText(self, label="Ваш коментар:"), 0, wx.LEFT | wx.RIGHT, 10)
        self.new = wx.TextCtrl(self, style=wx.TE_MULTILINE, size=(-1, 90))
        self.new.SetName("Ваш коментар")
        root.Add(self.new, 0, wx.ALL | wx.EXPAND, 10)
        btns = wx.BoxSizer(wx.HORIZONTAL)
        self.send = wx.Button(self, label="Надіслати коментар")
        self.send.Bind(wx.EVT_BUTTON, self.on_send)
        btns.Add(self.send, 0, wx.RIGHT, 8)
        btns.AddStretchSpacer()
        btns.Add(wx.Button(self, wx.ID_CANCEL, "Закрити"))
        root.Add(btns, 0, wx.ALL | wx.EXPAND, 10)
        self.SetSizer(root)
        self._alive = True
        self.Bind(wx.EVT_WINDOW_DESTROY, self._on_destroy)
        self.lb.SetFocus()
        threading.Thread(target=self._load, daemon=True).start()

    def _on_destroy(self, e):
        if e.GetEventObject() is self:
            self._alive = False
        e.Skip()

    def _load(self):
        try:
            items = youtube.comments(self.item, self.frame.settings)
            rows = []
            for c in items:
                tail = []
                if c["likes"]:
                    tail.append("вподобань: %d" % c["likes"])
                if c["when"]:
                    tail.append(c["when"])
                rows.append("%s: %s%s" % (c["author"] or "Користувач", c["text"].replace("\n", " "),
                                          " (%s)" % ", ".join(tail) if tail else ""))
            n = len(rows)
            if not rows:
                rows = ["Коментарів немає або вони вимкнені."]
        except youtube.YtError as e:
            rows, n = [str(e)], 0
        except Exception as e:  # noqa: BLE001
            rows, n = ["Не вдалося завантажити коментарі: %s" % e], 0
        wx.CallAfter(self._fill, rows, n)

    def _fill(self, rows, n):
        if not self._alive:
            return
        self.lb.Set(rows)
        self.lb.SetSelection(0)
        self.frame.say("Коментарів: %d" % n if n else rows[0], interrupt=False)

    def on_send(self, _e):
        text = self.new.GetValue().strip()
        if not text:
            self.frame.say("Спочатку напишіть коментар")
            self.new.SetFocus()
            return
        self.send.Disable()
        self.frame.say("Надсилаю коментар")

        def work():
            try:
                self.frame.account.post_comment(self.item.id, text)
                wx.CallAfter(self._sent, True, "")
            except youtube.YtError as e:
                wx.CallAfter(self._sent, False, str(e))
            except Exception as e:  # noqa: BLE001
                wx.CallAfter(self._sent, False, "Не вдалося надіслати коментар: %s" % e)

        threading.Thread(target=work, daemon=True).start()

    def _sent(self, ok, err):
        if not self._alive:
            return
        self.send.Enable()
        if ok:
            self.new.SetValue("")
            self.frame.say("Коментар надіслано")
        else:
            self.frame.say(err)


class DownloadDialog(wx.Dialog):
    """Вибір формату й якості перед завантаженням (Ctrl+D)."""

    def __init__(self, parent, title: str, default_spec: str = "mp3:best"):
        super().__init__(parent, title="Завантажити", style=wx.DEFAULT_DIALOG_STYLE)
        self.spec = None
        self.remember = False
        root = wx.BoxSizer(wx.VERTICAL)
        label = wx.StaticText(self, label="Що завантажити: %s" % title)
        label.Wrap(420)
        root.Add(label, 0, wx.ALL, 12)
        row = wx.BoxSizer(wx.HORIZONTAL)
        row.Add(wx.StaticText(self, label="Формат і якість:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self.choice = wx.Choice(self, choices=[c[1] for c in DOWNLOAD_CHOICES])
        self.choice.SetName("Формат і якість")
        self.choice.SetSelection(_idx(DOWNLOAD_CHOICES, default_spec))
        row.Add(self.choice, 1)
        root.Add(row, 0, wx.LEFT | wx.RIGHT | wx.EXPAND, 12)
        self.cb = wx.CheckBox(self, label="Запам'ятати цей вибір для клавіш F3 / F4")
        root.Add(self.cb, 0, wx.ALL, 12)
        btns = wx.BoxSizer(wx.HORIZONTAL)
        ok = wx.Button(self, wx.ID_OK, "Завантажити")
        ok.SetDefault()
        btns.Add(ok, 0, wx.RIGHT, 8)
        btns.Add(wx.Button(self, wx.ID_CANCEL, "Скасувати"))
        root.Add(btns, 0, wx.ALL | wx.ALIGN_RIGHT, 12)
        self.SetSizerAndFit(root)
        self.SetMinSize((460, -1))
        self.choice.SetFocus()

    def result(self):
        """-> (spec, запам'ятати) або None, якщо скасовано."""
        i = self.choice.GetSelection()
        if self.GetReturnCode() != wx.ID_OK or i < 0:
            return None
        return DOWNLOAD_CHOICES[i][0], self.cb.GetValue()


class TextDialog(wx.Dialog):
    """Довгий текст (опис відео): рядок для читання зчитувачем, копіювання, закриття Escape."""

    def __init__(self, parent, title: str, text: str):
        super().__init__(parent, title=title, style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.text = text
        self.box = wx.TextCtrl(self, value=text, style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_WORDWRAP)
        self.box.SetName(title)
        copy = wx.Button(self, label="Копіювати все")
        copy.Bind(wx.EVT_BUTTON, self._copy)
        close = wx.Button(self, wx.ID_CANCEL, "Закрити")
        row = wx.BoxSizer(wx.HORIZONTAL)
        row.Add(copy, 0, wx.RIGHT, 8)
        row.Add(close, 0)
        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(self.box, 1, wx.ALL | wx.EXPAND, 12)
        root.Add(row, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.ALIGN_RIGHT, 12)
        self.SetSizer(root)
        self.SetSize((640, 480))
        self.SetMinSize((360, 240))
        self.box.SetFocus()
        self.box.SetInsertionPoint(0)

    def _copy(self, _e):
        if wx.TheClipboard.Open():
            wx.TheClipboard.SetData(wx.TextDataObject(self.text))
            wx.TheClipboard.Close()
            wx.MessageBox("Текст скопійовано.", "Опис", wx.OK, self)


class ActivationDialog(wx.Dialog):
    """Активація: стан, код пристрою (його надсилають розробнику) і поле для коду активації."""

    def __init__(self, parent, lic):
        super().__init__(parent, title="Активація", style=wx.DEFAULT_DIALOG_STYLE)
        self.lic = lic
        self.activated = False
        st = lic.status()
        if st.mode == "active":
            head = st.text
        elif st.mode == "trial":
            head = "Пробний режим. Лишилося: %s. Щоб продовжити після цього, введіть код активації." % st.text
        else:
            head = "Пробний період закінчився. Відтворення й завантаження не працюють, поки не введено код активації."
        if st.note:
            head += " " + st.note
        from .licensing import key_fingerprint
        steps = ("Як активувати: 1. Надішліть розробнику код пристрою (кнопка «Копіювати код пристрою»). "
                 "2. Отриманий код активації вставте в поле нижче (Ctrl+V) і натисніть «Активувати». "
                 "Відбиток ключа програми: %s." % key_fingerprint())
        self.info = wx.TextCtrl(self, value=head + "\n\n" + steps,
                                style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_WORDWRAP, size=(540, 120))
        self.info.SetName("Стан активації")
        lab1 = wx.StaticText(self, label="Код пристрою:")
        self.dev = wx.TextCtrl(self, value=lic.device_code(), style=wx.TE_READONLY)
        self.dev.SetName("Код пристрою")
        copy = wx.Button(self, label="Копіювати код пристрою")
        copy.Bind(wx.EVT_BUTTON, self._copy_device)
        lab2 = wx.StaticText(self, label="Код активації:")
        self.code = wx.TextCtrl(self)
        self.code.SetName("Код активації")
        ok = wx.Button(self, wx.ID_OK, "Активувати")
        ok.SetDefault()
        ok.Bind(wx.EVT_BUTTON, self._activate)
        close = wx.Button(self, wx.ID_CANCEL, "Закрити")
        row = wx.BoxSizer(wx.HORIZONTAL)
        row.Add(ok, 0, wx.RIGHT, 8)
        row.Add(close, 0)
        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(self.info, 0, wx.ALL | wx.EXPAND, 12)
        root.Add(lab1, 0, wx.LEFT | wx.RIGHT, 12)
        root.Add(self.dev, 0, wx.ALL | wx.EXPAND, 12)
        root.Add(copy, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 12)
        root.Add(lab2, 0, wx.LEFT | wx.RIGHT, 12)
        root.Add(self.code, 0, wx.ALL | wx.EXPAND, 12)
        root.Add(row, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.ALIGN_RIGHT, 12)
        self.SetSizerAndFit(root)
        self.code.SetFocus()

    def _copy_device(self, _e):
        if wx.TheClipboard.Open():
            wx.TheClipboard.SetData(wx.TextDataObject(self.dev.GetValue()))
            wx.TheClipboard.Close()
            wx.MessageBox("Код пристрою скопійовано. Надішліть його розробнику.", "Активація", wx.OK, self)

    def _activate(self, _e):
        ok, msg = self.lic.activate(self.code.GetValue())
        if ok:
            self.activated = True
            wx.MessageBox("Готово. " + msg + " Дякуємо!", "Активація", wx.OK, self)
            self.EndModal(wx.ID_OK)
        else:
            wx.MessageBox(msg, "Код не прийнято", wx.OK | wx.ICON_WARNING, self)
            self.code.SetFocus()


class BookmarksDialog(wx.Dialog):
    """Закладки відео: перейти до вибраної або видалити. selected - номер вибраної після «Перейти»."""

    def __init__(self, parent, labels: list, on_delete):
        super().__init__(parent, title="Закладки відео", style=wx.DEFAULT_DIALOG_STYLE)
        self.on_delete = on_delete
        self.selected = -1
        self.box = wx.ListBox(self, choices=labels, size=(420, 220))
        self.box.SetName("Закладки")
        self.box.SetSelection(0)
        go = wx.Button(self, wx.ID_OK, "Перейти")
        go.SetDefault()
        go.Bind(wx.EVT_BUTTON, self._go)
        rm = wx.Button(self, label="Видалити")
        rm.Bind(wx.EVT_BUTTON, self._delete)
        close = wx.Button(self, wx.ID_CANCEL, "Закрити")
        row = wx.BoxSizer(wx.HORIZONTAL)
        for b in (go, rm, close):
            row.Add(b, 0, wx.RIGHT, 8)
        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(self.box, 1, wx.ALL | wx.EXPAND, 12)
        root.Add(row, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.ALIGN_RIGHT, 12)
        self.SetSizerAndFit(root)
        self.box.SetFocus()

    def _go(self, _e):
        self.selected = self.box.GetSelection()
        if self.selected >= 0:
            self.EndModal(wx.ID_OK)

    def _delete(self, _e):
        i = self.box.GetSelection()
        if i < 0:
            return
        labels = self.on_delete(i)
        if labels is None:
            return
        self.box.Set(labels)
        if labels:
            self.box.SetSelection(min(i, len(labels) - 1))
        else:
            self.EndModal(wx.ID_CANCEL)

