"""Робота з YouTube через yt-dlp (окремий процес: легко оновлювати `yt-dlp -U`)."""
import json
import re
import logging
import os
import subprocess
import unicodedata
import sys
import threading
from dataclasses import dataclass, field
from urllib.parse import quote

from . import paths

log = logging.getLogger("youstream.youtube")

CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0

FIRST_BATCH = 30      # скільки елементів показати одразу, решта підвантажується у фоні
NEXT_BATCH = 50       # як часто додавати наступні елементи у список

_tl = threading.local()


def set_progress_sink(fn) -> None:
    """Для поточного потоку: fn(batch, offset, wanted) викликається, коли list_url має нову порцію
    елементів. fn=None вимикає. Так списки показують перші ~30 результатів, не чекаючи всіх."""
    _tl.sink = fn


NEED_COMPONENTS = ("Потрібні додаткові компоненти. Відкрийте вкладку Ви, пункт Компоненти, "
                   "і завантажте їх.")


class YtError(Exception):
    """Помилка з готовим повідомленням для користувача."""


class AuthRequired(YtError):
    pass


@dataclass
class Item:
    id: str = ""
    title: str = ""
    channel: str = ""
    duration: int = 0
    url: str = ""
    kind: str = "video"      # video | channel | playlist | local | menu
    path: str = ""           # для локальних файлів
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {"id": self.id, "title": self.title, "channel": self.channel,
                "duration": self.duration, "url": self.url, "kind": self.kind, "path": self.path}

    @staticmethod
    def from_dict(d: dict) -> "Item":
        return Item(id=d.get("id", ""), title=d.get("title", ""), channel=d.get("channel", ""),
                    duration=int(d.get("duration") or 0), url=d.get("url", ""),
                    kind=d.get("kind", "video"), path=d.get("path", ""))


def ytdlp_cmd() -> list:
    exe = paths.tool_path("yt-dlp")
    if exe:
        return [exe]
    if getattr(sys, "frozen", False):
        raise YtError(NEED_COMPONENTS)
    return [sys.executable, "-m", "yt_dlp"]


def interface_lang(settings) -> str:
    """Мова інтерфейсу YouTube. Порожньо в налаштуваннях - українська за замовчуванням;
    «off» або «-» - вимкнути (англійська, як віддає YouTube без вказівки)."""
    tl = _opt(settings, "list_lang", "")
    tl = tl.strip() if isinstance(tl, str) else ""
    if not tl:
        return "uk"
    if tl.lower() in ("off", "-", "en", "none"):
        return ""
    return tl if re.fullmatch(r"[A-Za-z]{2,3}(-[A-Za-z0-9]{2,4})?", tl) else ""


def base_args(settings, with_lang: bool = True) -> list:
    args = ["--no-warnings", "--no-colors", "--encoding", "utf-8"]
    ff = paths.tool_path("ffmpeg")
    if ff:
        args += ["--ffmpeg-location", os.path.dirname(ff)]
    # Мова інтерфейсу YouTube (переклад назв тощо). yt-dlp розбирає «2 hours ago» лише англійською,
    # тому для списків час публікації окремо добирається англомовним запитом (див. list_url).
    tl = interface_lang(settings)
    if with_lang and tl:
        args += ["--extractor-args", "youtube:lang=%s" % tl]
    mode = settings["cookies_mode"]
    if mode == "browser" and settings["cookies_browser"]:
        args += ["--cookies-from-browser", settings["cookies_browser"]]
    elif mode == "file" and os.path.isfile(settings["cookies_file"] or ""):
        args += ["--cookies", settings["cookies_file"]]
    return args


def _run(args: list, timeout: int = 120):
    try:
        p = subprocess.run(args, capture_output=True, timeout=timeout,
                           creationflags=CREATE_NO_WINDOW, env=paths.tool_env())
    except FileNotFoundError:
        raise YtError(NEED_COMPONENTS)
    except subprocess.TimeoutExpired:
        raise YtError("Сервер YouTube не відповів вчасно. Спробуйте ще раз.")
    out = p.stdout.decode("utf-8", "replace")
    err = p.stderr.decode("utf-8", "replace")
    return p.returncode, out, err


_SMALLCAPS = str.maketrans("ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘʀꜱᴛᴜᴠᴡʏᴢ", "abcdefghijklmnoprstuvwyz")
_MOJIBAKE = re.compile("[РС][\u0400-\u04ff\u2018-\u203a\u00a0-\u00bf]")


def _fix_mojibake(s: str) -> str:
    """Якщо UTF-8 текст прочитано в кодуванні cp1251 («РќРѕРІРёРЅРё»), повертає нормальний вигляд."""
    if _MOJIBAKE.search(s):
        for enc in ("cp1251", "latin-1"):
            try:
                fixed = s.encode(enc).decode("utf-8")
            except (UnicodeEncodeError, UnicodeDecodeError):
                continue
            if fixed and "\ufffd" not in fixed:
                return fixed
    return s


_EMOJI_MODE = "off"       # off - прибрати | symbol - показувати символами | words - замінювати словами


def emoji_mode() -> str:
    return _EMOJI_MODE


def keep_emoji() -> bool:
    return _EMOJI_MODE != "off"


def set_emoji_mode(mode: str):
    """off - емодзі прибираються; symbol - лишаються символами (їх видно, голосить зчитувач екрана);
    words - замінюються українськими назвами (чути за будь-яких налаштувань зчитувача)."""
    global _EMOJI_MODE
    _EMOJI_MODE = mode if mode in ("off", "symbol", "words") else "symbol"


def set_keep_emoji(flag: bool):
    set_emoji_mode("symbol" if flag else "off")


def clean_text(s: str) -> str:
    """Робить назви читабельними: звичайні літери замість декоративних (𝗕𝗼𝗹𝗱, ｆｕｌｌ, ᴍᴀʟʟ ᴄᴀᴘs),
    без емодзі й невидимих знаків, які зчитувач промовляє по літерах чи «спотикається» на них."""
    if not s:
        return s
    orig = s.strip()
    s = unicodedata.normalize("NFKC", _fix_mojibake(s)).translate(_SMALLCAPS)
    out = []
    for ch in s:
        cat = unicodedata.category(ch)
        if ch in "\t\n\r\u00a0":
            out.append(" ")
        elif _EMOJI_MODE != "off" and (cat == "So" or ch in "\ufe0e\ufe0f\u20e3"):
            out.append(ch)                      # емодзі лишаємо
        elif cat in ("Cc", "Cf", "Cs", "Co", "Cn", "So") or ch in "\ufe0e\ufe0f\u20e3":
            continue
        else:
            out.append(ch)
    res = re.sub(r"\s+", " ", "".join(out)).strip()
    if _EMOJI_MODE == "words" and res:
        from .emoji import to_words        # режим «словами»: символи замінюються назвами
        res = to_words(res) or res
    return res or orig


_UNITS = {"second": ("секунду", "секунди", "секунд"), "minute": ("хвилину", "хвилини", "хвилин"),
          "hour": ("годину", "години", "годин"), "day": ("день", "дні", "днів"),
          "week": ("тиждень", "тижні", "тижнів"), "month": ("місяць", "місяці", "місяців")}


def _json_line(out: str) -> str:
    line = ""
    for ln in out.splitlines():
        if ln.strip().startswith("{"):
            line = ln
    return line


def _generic_unavailable(err: str) -> bool:
    """«Відео недоступне» без пояснення причини (приватне, регіон, вік, вхід тощо)."""
    low = (err or "").lower()
    if not ("unavailable" in low or "недоступн" in low):
        return False
    specific = ("private", "приватне", "country", "країні", "регіон", "sign in", "увійд", "age", "вік", "removed",
                "видален", "terminated", "copyright", "will begin", "premiere")
    return not any(w in low for w in specific)


def _friendly(err: str) -> str:
    low = err.lower()
    m = re.search(r"(?:will begin|premieres?|starts?) in (\d+) (second|minute|hour|day|week|month)", low)
    if m:
        n = int(m.group(1))
        return ("Це відео ще недоступне: трансляція чи прем'єра почнеться за %d %s."
                % (n, _plural(n, *_UNITS[m.group(2)])))
    if "will begin shortly" in low or "premiere will begin" in low or "live event will begin" in low:
        return "Це відео ще недоступне: трансляція чи прем'єра почнеться найближчим часом."
    if "cookie" in low and ("could not copy" in low or "decrypt" in low or "permission" in low):
        return ("Не вдалося прочитати cookies браузера. Закрийте браузер або оберіть Firefox "
                "чи файл cookies.txt.")
    if ("sign in" in low or "log in" in low or "login" in low or "увійдіть" in low or "увійти" in low
            or "потрібно ввійти" in low):
        return "Потрібен вхід в акаунт. Налаштуйте його в розділі Ви, Налаштування."
    if "unable to download" in low or "urlopen" in low or "getaddrinfo" in low:
        return "Немає з'єднання з інтернетом."
    if "private" in low or "приватне" in low:
        return "Це відео приватне."
    if "country" in low or "вашій країні" in low or "вашому регіоні" in low or "geo" in low:
        return "Це відео недоступне у вашому регіоні."
    if "unavailable" in low or "недоступн" in low:
        return ("Відео недоступне: його могли видалити, зробити приватним або обмежити для вашого регіону. "
                "Перейдіть до наступного.")
    if "javascript" in low or "js runtime" in low or "deno" in low:
        return NEED_COMPONENTS
    last = [ln for ln in err.strip().splitlines() if ln.strip()]
    return "Помилка YouTube: " + (last[-1][:200] if last else "невідома")


def _classify(e: dict) -> Item | None:
    url = e.get("url") or e.get("webpage_url") or ""
    eid = e.get("id") or ""
    if not url and eid:
        url = "https://www.youtube.com/watch?v=" + eid
    ie = (e.get("ie_key") or "").lower()
    kind = "video"
    if "/playlist?list=" in url or ie == "youtubeplaylist" or (eid.startswith(("PL", "OL", "UU", "FL", "RD"))
                                                               and "watch?v=" not in url):
        kind = "playlist"
    elif ie in ("youtubetab",) or "/channel/" in url or "/@" in url or "/user/" in url or "/c/" in url:
        kind = "channel" if "list=" not in url else "playlist"
    if kind == "video" and eid and len(eid) == 11 and "watch?v=" not in url:
        url = "https://www.youtube.com/watch?v=" + eid
    title = clean_text(e.get("title") or e.get("channel") or e.get("uploader") or "")
    if not title:
        return None
    dur = e.get("duration") or 0
    try:
        dur = int(dur)
    except (TypeError, ValueError):
        dur = 0
    ch = clean_text(e.get("channel") or e.get("uploader") or "")
    extra = {}
    try:
        views = int(e.get("view_count") or 0)
    except (TypeError, ValueError):
        views = 0
    if views and kind == "video":
        extra["views"] = views
    cid = e.get("channel_id") or ""
    if not cid and kind == "channel" and eid.startswith("UC"):
        cid = eid
    if cid:
        extra["channel_id"] = cid
    ls = e.get("live_status")
    if ls == "is_upcoming" or e.get("is_upcoming"):
        try:
            ts = int(e.get("release_timestamp") or e.get("timestamp") or 0)
        except (TypeError, ValueError):
            ts = 0
        extra["upcoming"] = ts
        extra["published"] = "Трансляція " + (("почнеться " + upcoming_text(ts)) if ts else "ще не почалася")
    elif ls == "is_live" or e.get("is_live"):
        extra["published"] = "Прямий ефір"
    else:
        when = _published_text(e)
        if when:
            extra["published"] = when
    if kind == "channel":
        bits = ["канал"]
        vc = e.get("playlist_count") or e.get("n_entries") or e.get("video_count")
        if vc:
            bits.append("відео: %s" % vc)
        fc = e.get("channel_follower_count")
        if fc:
            bits.append("підписників: %s" % _short_num(fc))
        ch = ", ".join(bits)
    elif kind == "playlist":
        n = e.get("playlist_count") or e.get("n_entries")
        ch = (ch + " · " if ch else "") + "список" + (f" ({n})" if n else "")
    return Item(id=eid, title=title, channel=ch, duration=dur, url=url, kind=kind, extra=extra)


class _Stream:
    """yt-dlp як потік рядків: можна обробляти результати, поки вони ще надходять."""

    def __init__(self, args: list, timeout: int = 240):
        try:
            self.p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                      creationflags=CREATE_NO_WINDOW, env=paths.tool_env())
        except FileNotFoundError:
            raise YtError(NEED_COMPONENTS)
        self.timed_out = False
        self._err: list = []
        self._t = threading.Thread(target=lambda: self._err.append(self.p.stderr.read()), daemon=True)
        self._t.start()
        self._timer = threading.Timer(timeout, self.abort)
        self._timer.daemon = True
        self._timer.start()

    def abort(self):
        self.timed_out = True
        try:
            self.p.kill()
        except OSError:
            pass

    def lines(self):
        for raw in self.p.stdout:
            yield raw.decode("utf-8", "replace")

    def finish(self):
        self.p.wait()
        self._timer.cancel()
        self._t.join(timeout=2)
        err = self._err[0].decode("utf-8", "replace") if self._err else ""
        return self.p.returncode, err


def _short_num(n) -> str:
    try:
        n = int(n)
    except (TypeError, ValueError):
        return str(n)
    if n >= 1_000_000:
        return ("%.1f млн" % (n / 1e6)).replace(".0", "")
    if n >= 1000:
        return ("%.1f тис." % (n / 1e3)).replace(".0", "")
    return str(n)


def _plural(n: int, one: str, few: str, many: str) -> str:
    if n % 10 == 1 and n % 100 != 11:
        return one
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return few
    return many


def ago_text(ts: float, now: float | None = None) -> str:
    """Скільки часу тому: «3 години тому», «вчора», «2 тижні тому»."""
    import time as _t
    d = int((now or _t.time()) - ts)
    if d < 0:
        d = 0
    if d < 3600:
        m = max(1, d // 60)
        return "%d %s тому" % (m, _plural(m, "хвилину", "хвилини", "хвилин"))
    if d < 86400:
        h = d // 3600
        return "%d %s тому" % (h, _plural(h, "годину", "години", "годин"))
    days = d // 86400
    if days == 1:
        return "вчора"
    if days < 7:
        return "%d %s тому" % (days, _plural(days, "день", "дні", "днів"))
    if days < 30:
        w = days // 7
        return "%d %s тому" % (w, _plural(w, "тиждень", "тижні", "тижнів"))
    if days < 365:
        m = days // 30
        return "%d %s тому" % (m, _plural(m, "місяць", "місяці", "місяців"))
    y = days // 365
    return "%d %s тому" % (y, _plural(y, "рік", "роки", "років"))


def upcoming_text(ts: float, now: float | None = None) -> str:
    """Коли почнеться трансляція: «сьогодні о 18:00 (за 3 год)», «завтра о 10:30», «25.10 о 20:00»."""
    import time as _t
    now = now if now is not None else _t.time()
    d = ts - now
    if d <= 0:
        return "вже має початися"
    loc, cur = _t.localtime(ts), _t.localtime(now)
    tomorrow = _t.localtime(now + 86400)
    if (loc.tm_year, loc.tm_yday) == (cur.tm_year, cur.tm_yday):
        day = "сьогодні"
    elif (loc.tm_year, loc.tm_yday) == (tomorrow.tm_year, tomorrow.tm_yday):
        day = "завтра"
    else:
        day = _t.strftime("%d.%m", loc)
    out = "%s о %s" % (day, _t.strftime("%H:%M", loc))
    mins = int(d // 60)
    if mins < 60:
        out += " (за %d хв)" % max(1, mins)
    elif mins < 48 * 60:
        out += " (за %d год)" % (mins // 60)
    return out


def _published_text(e: dict) -> str:
    ts = e.get("release_timestamp") or e.get("timestamp")
    if ts:
        try:
            return ago_text(float(ts))
        except (TypeError, ValueError):
            pass
    ud = str(e.get("upload_date") or "")
    if len(ud) == 8 and ud.isdigit():
        import calendar
        try:
            return ago_text(calendar.timegm((int(ud[:4]), int(ud[4:6]), int(ud[6:]), 12, 0, 0)))
        except (ValueError, OverflowError):
            pass
    return ""


def _parse_line(line: str):
    line = line.strip()
    if not line.startswith("{"):
        return None
    try:
        return _classify(json.loads(line))
    except ValueError:
        return None


class _DateFetch:
    """Час публікації для списків, коли мова інтерфейсу YouTube не англійська: yt-dlp розуміє
    «2 hours ago» лише англійською. Тому паралельно йде такий самий запит без мови, і з нього
    беремо час за id відео, а назви лишаються перекладеними."""

    def __init__(self, args: list):
        self.map: dict = {}
        self._t = threading.Thread(target=self._work, args=(args,), daemon=True)
        self._t.start()

    def _work(self, args: list) -> None:
        try:
            _code, out, _err = _run(args, 150)
            for line in out.splitlines():
                it = _parse_line(line)
                if it and it.extra.get("published"):
                    self.map[it.id] = it.extra["published"]
        except Exception:
            pass

    def fill(self, items: list) -> list:
        self._t.join(150)
        for it in items:
            if it.kind == "video" and not it.extra.get("published") and it.id in self.map:
                it.extra["published"] = self.map[it.id]
        return items


def list_url(url: str, settings, count: int | None = None, stream: bool = True) -> list:
    """Плоский список з будь-якої URL/спеціального ':ytsubs' тощо.

    Якщо для потоку задано set_progress_sink і елементів потрібно більше за FIRST_BATCH,
    перші результати віддаються одразу (через sink), а повний список - у кінці.
    """
    count = count or int(settings["results_count"])
    tail = ["--flat-playlist", "-j", "--playlist-end", str(count), "--ignore-errors",
            "--extractor-args", "youtubetab:approximate_date", url]
    args = ytdlp_cmd() + base_args(settings) + tail
    dates = _DateFetch(ytdlp_cmd() + base_args(settings, with_lang=False) + tail) if interface_lang(settings) else None
    sink = getattr(_tl, "sink", None) if stream else None
    items: list = []
    if sink is None or count <= FIRST_BATCH:
        code, out, err = _run(args)
        for line in out.splitlines():
            it = _parse_line(line)
            if it:
                items.append(it)
        if dates:
            dates.fill(items)
    else:
        st = _Stream(args)
        sent = 0
        try:
            for line in st.lines():
                it = _parse_line(line)
                if not it:
                    continue
                items.append(it)
                if sent == 0 and len(items) >= FIRST_BATCH:
                    sink(dates.fill(items[:]) if dates else items[:], 0, count)
                    sent = len(items)
                elif sent and len(items) - sent >= NEXT_BATCH:
                    sink(dates.fill(items[sent:]) if dates else items[sent:], sent, count)
                    sent = len(items)
        except BaseException:
            st.abort()
            raise
        code, err = st.finish()
        if sent and len(items) > sent:
            sink(dates.fill(items[sent:]) if dates else items[sent:], sent, count)
    if dates:
        dates.fill(items)
    if not items and code != 0:
        raise YtError(_friendly(err))
    if not items:
        raise YtError("Нічого не знайдено.")
    return items


def search(query: str, settings, count: int | None = None, sp: str | None = None) -> list:
    """sp - необов'язковий фільтр YouTube (пряма трансляція, довге відео...)."""
    url = "https://www.youtube.com/results?search_query=" + quote(query)
    if sp:
        url += "&sp=" + sp
    return list_url(url, settings, count)


def _need_account(settings):
    if not settings.has_account():
        raise AuthRequired("Потрібен вхід в акаунт. Налаштуйте його в розділі Ви, Налаштування.")


def home(settings) -> list:
    if settings.has_account():
        try:
            return list_url(":ytrec", settings)
        except YtError as e:
            log.info("Рекомендації недоступні: %s", e)
    return search(settings["home_fallback_query"], settings)


def _clean_channel(name: str) -> str:
    return (name or "").split(" · ")[0].strip()


def recommendations(settings, history: list, is_blocked=None) -> list:
    """Рекомендації для вкладки «Домашня сторінка».

    З акаунтом - рекомендації YouTube. Без акаунта (або якщо їх не вдалося отримати) -
    за нещодавніми переглядами: беруться останні різні канали й назви, по кожному робиться
    пошук, результати перемішуються, уже переглянуте й чорний список прибираються.
    """
    import concurrent.futures
    import random

    seen_ids = {h.get("id") for h in history if h.get("id")}
    out, ids = [], set()

    def add(items):
        for it in items:
            if it.kind != "video" or not it.id or it.id in ids or it.id in seen_ids:
                continue
            if is_blocked and is_blocked(it):
                continue
            ids.add(it.id)
            out.append(it)

    if settings.has_account():
        try:
            add(list_url(":ytrec", settings, stream=False))
        except YtError as e:
            log.info("Рекомендації акаунта недоступні: %s", e)
    want = int(settings["results_count"])
    if len(out) >= want:
        return out[:want]

    queries, seen_q = [], set()
    for h in history[:40]:
        ch = _clean_channel(h.get("channel", ""))
        if ch and ch.lower() not in seen_q and ch.lower() != "канал":
            seen_q.add(ch.lower())
            queries.append(ch)
        if len(queries) >= 5:
            break
    for h in history[:3]:                       # ще й за темою трьох останніх
        t = (h.get("title") or "")[:60]
        if t and t.lower() not in seen_q:
            seen_q.add(t.lower())
            queries.append(t)
    if not queries:
        queries = [settings["home_fallback_query"]]

    per = max(10, min(40, want // max(1, len(queries)) + 5))
    batches = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        futs = [ex.submit(search, q, settings, per) for q in queries]
        for f in futs:
            try:
                batches.append(f.result())
            except YtError as e:
                log.info("Пошук для рекомендацій: %s", e)
            except Exception:  # noqa: BLE001
                log.exception("recommendations")
    if not batches and not out:
        raise YtError("Не вдалося отримати рекомендації. Перевірте інтернет.")
    # чергуємо джерела, щоб не було серії від одного каналу
    for rnd in range(max(len(b) for b in batches) if batches else 0):
        row = [b[rnd] for b in batches if rnd < len(b)]
        random.shuffle(row)
        add(row)
    return out[:want]


def subscriptions(settings) -> list:
    _need_account(settings)
    return list_url(":ytsubs", settings)


def subscribed_channels(settings) -> list:
    _need_account(settings)
    return list_url("https://www.youtube.com/feed/channels", settings, 200)


def account_history(settings) -> list:
    _need_account(settings)
    return list_url(":ythis", settings, 100)


def watch_later(settings) -> list:
    _need_account(settings)
    return list_url(":ytwatchlater", settings, 200)


def liked(settings) -> list:
    _need_account(settings)
    return list_url(":ytfav", settings, 200)


def account_playlists(settings) -> list:
    _need_account(settings)
    return list_url("https://www.youtube.com/feed/playlists", settings, 100)


def open_container(item: Item, settings) -> list:
    url = item.url
    if item.kind == "channel":
        url = url.rstrip("/")
        if not url.endswith(("/videos", "/streams", "/shorts")):
            url += "/videos"
    return list_url(url, settings, 100 if item.kind == "playlist" else None)


def channel_of(item: Item, settings) -> Item | None:
    """Знаходить канал відео (для пункту «Відкрити канал»)."""
    args = ytdlp_cmd() + base_args(settings) + ["--no-playlist", "--skip-download", "--print",
                                              "%(channel_url)s||%(channel)s", item.url]
    code, out, err = _run(args, 60)
    line = out.strip().splitlines()[-1] if out.strip() else ""
    if "||" in line:
        url, name = line.split("||", 1)
        if url.startswith("http"):
            return Item(id=url, title=name, channel="канал", url=url, kind="channel")
    return None


def channel_info(item: Item, settings) -> tuple:
    """-> (channel_id, назва, url) каналу відео або каналу-елемента."""
    if item.kind == "channel":
        m = __import__("re").search(r"/channel/(UC[\w-]{22})", item.url or "")
        return (m.group(1) if m else ""), item.title, item.url
    args = ytdlp_cmd() + base_args(settings) + ["--no-playlist", "--skip-download", "--print",
                                              "%(channel_id)s||%(channel)s||%(channel_url)s", item.url]
    code, out, err = _run(args, 60)
    line = out.strip().splitlines()[-1] if out.strip() else ""
    parts = line.split("||")
    if len(parts) == 3 and parts[0] not in ("", "NA"):
        return parts[0], parts[1], parts[2]
    if len(parts) == 2 and parts[0].startswith("http"):       # сумісність зі старим форматом
        return "", parts[1], parts[0]
    raise YtError(_friendly(err) if code != 0 else "Канал не знайдено.")


@dataclass
class Resolved:
    stream_url: str
    title: str = ""
    channel: str = ""
    duration: int = 0
    headers: dict = field(default_factory=dict)
    chapters: list = field(default_factory=list)   # [(start_sec, title)]
    live: bool = False
    audio_url: str = ""            # окремий аудіопотік, якщо відео й звук йдуть окремо (відеорежим)
    video_id: str = ""
    description: str = ""
    audio_langs: list = field(default_factory=list)   # [{code, name, original}] мови звукових доріжок
    audio_lang: str = ""           # мова вибраної доріжки (якщо відома)
    subs_manual: dict = field(default_factory=dict)   # {мова: [{ext, url}]} субтитри автора
    subs_auto: dict = field(default_factory=dict)     # автоматичні субтитри й переклади


def _opt(settings, key: str, default):
    try:
        return settings[key]
    except KeyError:
        return default


def _audio_alts(settings, base: str = "ba", extra: str = "", lang: str | None = None) -> list:
    """Варіанти звукової доріжки за порядком переваги. На YouTube багато відео має кілька доріжок
    (оригінал і автоматичний дубляж). Без цього вибору yt-dlp міг узяти дубльовану замість оригіналу.
    lang - код мови для цього відео («uk», «en»...) або «orig»; без нього - з налаштувань."""
    code = (lang or str(_opt(settings, "audio_lang", "orig") or "orig")).strip().lower()
    alts = []
    if code and code != "orig":
        if _opt(settings, "prefer_ad", True):
            # доріжка з описом сцен для незрячих (YouTube позначає її «descriptive»), якщо вона є цією мовою
            alts.append("%s[language^=%s][format_note*=descriptive]%s" % (base, code, extra))
        alts.append("%s[language^=%s]%s" % (base, code, extra))
    alts += ["%s[format_note*=original]%s" % (base, extra),
             "%s[format_note*=default]%s" % (base, extra),
             "%s%s" % (base, extra)]
    return alts


def _audio_format(settings, lang: str | None = None) -> str:
    q = _opt(settings, "audio_quality", "best")
    if q == "low":
        alts = _audio_alts(settings, "wa", "", lang)
    elif q == "medium":
        alts = _audio_alts(settings, "ba", "[abr<=128]", lang) + _audio_alts(settings, "ba", "", lang)
    else:
        alts = _audio_alts(settings, "ba", "", lang)
    return "/".join(alts + ["b"])


def _video_format(settings, lang: str | None = None) -> str:
    """Формат відео. Віддаємо перевагу H.264 до 30 кадрів/с (їх легко декодувати), звук - окремою
    доріжкою потрібної мови. Відео беремо БЕЗ звуку («bv», а не «bv*»): якщо взяти готовий файл
    зі звуком і додати ще окрему доріжку, звучали обидві мови. Лише якщо чистого відео немає -
    запасні варіанти."""
    h = str(settings["video_height"] or "720")
    cap = "[height<=%s]" % h if (h != "best" and h.isdigit()) else ""
    auds = _audio_alts(settings, "ba", "", lang)
    out = []
    for v in ("bv%s[fps<=30][vcodec^=avc1]" % cap, "bv%s[fps<=30]" % cap, "bv%s" % cap):
        out += ["%s+%s" % (v, a) for a in auds]
    out += ["b%s" % cap, "b"]
    return "/".join(out)


def audio_langs_of(info: dict) -> list:
    """Мови звукових доріжок відео: [{code, name, original}], оригінал першим."""
    seen, out = {}, []
    for f in info.get("formats") or []:
        if f.get("acodec") in (None, "none"):
            continue
        code = (f.get("language") or "").strip()
        if not code:
            continue
        note = (f.get("format_note") or "").lower()
        base = code.split("-")[0].lower()
        if base in seen:
            if "original" in note:
                seen[base]["original"] = True
            continue
        rec = {"code": base, "name": _lang_name(base), "original": "original" in note}
        seen[base] = rec
        out.append(rec)
    out.sort(key=lambda r: not r["original"])
    return out


def _lang_name(code: str) -> str:
    from .subtitles import lang_name
    return lang_name(code)


def resolve_audio(item: Item, settings) -> Resolved:
    return resolve(item, settings, video=False)


def resolve(item: Item, settings, video: bool = False, lang: str | None = None) -> Resolved:
    """Потік для відтворення. video=True - відео з якістю з налаштувань (відео й звук можуть
    бути окремими потоками), інакше лише звук. lang - мова звуку саме для цього відео."""
    fmt = _video_format(settings, lang) if video else _audio_format(settings, lang)
    args = ytdlp_cmd() + base_args(settings) + ["-j", "--no-playlist", "-f", fmt, item.url]
    code, out, err = _run(args, 90)
    line = _json_line(out)
    if not line and _generic_unavailable(err):
        # загальне «Відео недоступне» без причини: пробуємо ще раз зі стандартною мовою інтерфейсу YouTube
        # (запит із українським інтерфейсом міг бути причиною відмови)
        args = ytdlp_cmd() + base_args(settings, with_lang=False) + ["-j", "--no-playlist", "-f", fmt, item.url]
        code, out, err2 = _run(args, 90)
        line = _json_line(out)
        err = err2 or err
    if not line:
        raise YtError(_friendly(err))
    info = json.loads(line)
    url, audio_url = info.get("url"), ""
    rf = info.get("requested_formats") or []
    if video and len(rf) >= 2:
        vf = next((f for f in rf if f.get("vcodec") not in (None, "none")), rf[0])
        af = next((f for f in rf if f.get("acodec") not in (None, "none") and f is not vf), None)
        url = vf.get("url") or url
        audio_url = (af or {}).get("url") or ""
    if not url:
        raise YtError("Не вдалося отримати потік для відтворення.")
    chapters = [(float(c.get("start_time") or 0), c.get("title") or "")
                for c in (info.get("chapters") or [])]
    chosen = ""
    for f in (rf if rf else [info]):
        if f.get("acodec") not in (None, "none") and f.get("language"):
            chosen = str(f["language"]).split("-")[0].lower()
    return Resolved(stream_url=url, title=clean_text(info.get("title") or item.title),
                    channel=clean_text(info.get("channel") or info.get("uploader") or item.channel),
                    duration=int(info.get("duration") or item.duration or 0),
                    headers=info.get("http_headers") or {}, chapters=chapters,
                    live=bool(info.get("is_live")), audio_url=audio_url,
                    video_id=info.get("id") or item.id, description=info.get("description") or "",
                    audio_langs=audio_langs_of(info), audio_lang=chosen,
                    subs_manual=info.get("subtitles") or {},
                    subs_auto=info.get("automatic_captions") or {})


def fetch_subtitles(video_url: str, choice, settings) -> tuple:
    """Завантажує субтитри через yt-dlp (з тими ж cookies і запитами, що й відео: пряме звернення за
    адресою субтитрів YouTube відхиляє помилкою 429). -> (текст, розширення)."""
    import glob
    import shutil
    import tempfile
    import time
    tmp = tempfile.mkdtemp(prefix="ys_subs_")
    saw_429, last_err = False, ""
    try:
        # YouTube часто відповідає 429 на субтитри для «веб» клієнта (потрібен спеціальний токен).
        # Тому для готових субтитрів пробуємо кілька клієнтів по черзі: звичайний, Safari, мобільний веб.
        # Переклад (autotranslate) YouTube віддає найгірше: для нього одна спроба, інших способів немає.
        clients = (None,) if getattr(choice, "translated", False) else (None, "web_safari", "mweb")
        for client in clients:
            for old in glob.glob(os.path.join(tmp, "sub*")):
                try:
                    os.remove(old)
                except OSError:
                    pass
            extra = ["--extractor-args", "youtube:player_client=%s" % client] if client else []
            args = ytdlp_cmd() + base_args(settings) + extra + [
                "--skip-download", "--no-playlist", "--ignore-no-formats-error",
                "--write-subs", "--write-auto-subs",
                "--sub-langs", choice.key, "--sub-format", "json3/vtt/srt/best",
                "-o", os.path.join(tmp, "sub"), video_url]
            code, out, err = _run(args, 120)
            files = [f for f in glob.glob(os.path.join(tmp, "sub*")) if os.path.isfile(f)]
            for pref in ("json3", "vtt", "srt"):
                for f in files:
                    if f.lower().endswith("." + pref):
                        with open(f, "rb") as fh:
                            return fh.read().decode("utf-8", "replace"), pref
            low = (err or "").lower()
            if "429" in low or "too many requests" in low:
                saw_429 = True
                if len(clients) > 1:
                    time.sleep(1.5)
            elif err.strip():
                last_err = err
            log.info("Субтитри: спроба клієнтом %s не вдалась (%s)", client or "типовим",
                     (err.strip().splitlines() or ["без файлу"])[-1][:120])
        if saw_429:
            raise YtError("YouTube тимчасово обмежив запити субтитрів (429). Спробуйте за кілька хвилин.")
        raise YtError(_friendly(last_err) if last_err.strip() else "Для цієї мови субтитри отримати не вдалося.")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def describe(item: Item, settings) -> dict:
    """Опис відео та кілька даних про нього: {title, channel, description, date, views}."""
    args = ytdlp_cmd() + base_args(settings) + ["-j", "--no-playlist", "--skip-download", item.url]
    code, out, err = _run(args, 90)
    line = ""
    for ln in out.splitlines():
        if ln.strip().startswith("{"):
            line = ln
    if not line:
        raise YtError(_friendly(err))
    info = json.loads(line)
    return {"title": clean_text(info.get("title") or item.title),
            "channel": clean_text(info.get("channel") or info.get("uploader") or item.channel),
            "description": info.get("description") or "",
            "date": str(info.get("upload_date") or ""), "views": info.get("view_count"),
            "id": info.get("id") or item.id}


def availability(url: str, settings) -> str:
    """Стан відео: 'upcoming' (ще не почалося), 'live', 'available' (можна дивитись)
    або 'unknown' (не вдалося дізнатися)."""
    args = ytdlp_cmd() + base_args(settings) + ["--no-playlist", "--skip-download", "--print",
                                              "%(live_status)s", url]
    try:
        code, out, err = _run(args, 60)
    except YtError:
        return "unknown"
    low = (err or "").lower()
    if code != 0:
        if ("will begin" in low or "premiere" in low or "live event" in low or "upcoming" in low):
            return "upcoming"
        return "unknown"
    st = (out.strip().splitlines() or [""])[-1].strip()
    if st == "is_upcoming":
        return "upcoming"
    if st == "is_live":
        return "live"
    return "available"


def update_engine() -> str:
    """yt-dlp -U (працює для yt-dlp.exe). Повертає текст результату."""
    exe = paths.tool_path("yt-dlp")
    if not exe:
        raise YtError("Не знайдено bin\\yt-dlp.exe.")
    code, out, err = _run([exe, "-U"], 180)
    text = (out + err).strip().splitlines()
    return text[-1] if text else "Готово."


def engine_version() -> str:
    try:
        code, out, err = _run(ytdlp_cmd() + ["--version"], 20)
        return out.strip()
    except YtError:
        return "?"


def comments(item: Item, settings, count: int = 40) -> list:
    """Коментарі до відео через yt-dlp: [{author, text, likes, when}]."""
    args = ytdlp_cmd() + base_args(settings) + [
        "-j", "--no-playlist", "--skip-download", "--write-comments",
        "--extractor-args", "youtube:max_comments=%d,%d,0,0;comment_sort=top" % (count, count), item.url]
    code, out, err = _run(args, 180)
    line = ""
    for ln in out.splitlines():
        if ln.strip().startswith("{"):
            line = ln
    if not line:
        raise YtError(_friendly(err))
    info = json.loads(line)
    res = []
    for c in info.get("comments") or []:
        res.append({"author": clean_text((c.get("author") or "").lstrip("@")),
                    "text": clean_text(c.get("text") or ""),
                    "likes": int(c.get("like_count") or 0), "when": c.get("_time_text") or ""})
    return res
