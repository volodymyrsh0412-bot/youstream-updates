"""Головне вікно YouStream."""
import logging
import os
import re
import subprocess
import threading
import time

import wx

from . import APP_NAME, APP_VERSION, components, voice, youtube
from .account import Account
from .categories import CATEGORIES, category_query
from .config import Settings, developer_info, next_count, read_json, write_json
from .dialogs import ActionMenuDialog, CommentsDialog, DownloadDialog, SettingsDialog, show_help
from . import emoji, patching
from .extras import ExtrasMixin
from .downloader import Downloader, parse_spec, quality_label, subdir_for
from .icons import make_icon
from .keys import ACTIONS, KeyMap, display_combo, event_to_combo, is_plain
from .listpanel import ListPanel
from .playback import PlaybackMixin
from .speech import Speaker, fmt_time, fmt_time_spoken
from .store import Store
from . import theme
from .thumbs import ThumbFetcher
from .videoui import VideoMixin
from .youtube import Item, YtError

log = logging.getLogger("youstream.app")

MEDIA_KEYS = {"MediaPlayPause": "play_pause", "MediaNext": "next_track", "MediaPrev": "prev_track"}
# (ключ, назва) - порядок вкладок. «Сповіщення» видно лише при вході в акаунт.
SECTIONS = [("search", "Пошук"), ("home", "Головна"), ("recs", "Домашня сторінка"),
            ("subs", "Підписки"), ("notif", "Сповіщення"), ("you", "Ви")]
SECTION_NAMES = dict(SECTIONS)
WATCH_LATER = "Переглянути пізніше"
NOTIF_REFRESH_MS = 5 * 60 * 1000
START_PROMPT = "Введіть текст або натисніть F8 для голосового введення."


class MainFrame(ExtrasMixin, VideoMixin, PlaybackMixin, wx.Frame):
    def __init__(self):
        super().__init__(None, title=APP_NAME, size=(1000, 660))
        self.settings = Settings()
        youtube.set_emoji_mode(self.settings["emoji_mode"])
        self.store = Store()
        self.keymap = KeyMap(self.settings["keys"])
        self.speaker = Speaker(self.settings["speech_mode"])
        self.account = Account(self.settings)
        self.downloader = Downloader(self.settings, self.store,
                                     lambda kind, job: wx.CallAfter(self._dl_event, kind, job))
        self.thumbs = ThumbFetcher()
        self.thumbs.enabled = bool(self.settings["show_thumbnails"])
        self._voice_stop = None
        self._count_timer = None
        self._comp_busy = False
        self._seeking = False
        self._ui_cache = {}
        self._loaded = set()
        self._menu_actions = {}
        self._lazy = None
        self.visible = []          # ключі видимих вкладок
        self.current_key = "search"
        self.notif_unseen = 0
        self.now_label = None
        self._chrome_hidden = False
        self._chrome_focus = None
        self._last_activity = time.time()
        self._last_mouse = wx.GetMousePosition()
        self._info_txt = ""
        self._bottom_idx = 0
        self._subbed = None            # імена каналів, на які підписані (None - ще не знаємо)
        self.chan_state = read_json(os.path.join(self.store.dir, "channels.json"), {})

        self._build_ui()
        self.init_playback()
        self.init_extras()
        self.init_license()
        self.init_updates()
        wx.CallLater(15000, patching.mark_ok)       # дожили до 15-ї секунди: оновлення справне
        self._apply_mode_ui()
        self.build_menus()
        self.apply_theme()

        self.Bind(wx.EVT_MENU, self._on_menu)
        self.Bind(wx.EVT_CHAR_HOOK, self.on_char_hook)
        self.Bind(wx.EVT_CLOSE, self.on_close)
        self.timer = wx.Timer(self)
        self.Bind(wx.EVT_TIMER, lambda e: self.playback_tick(), self.timer)
        self.timer.Start(500)

        self.CreateStatusBar()
        self.Centre()
        self.show_you_menu()
        self.show_home_menu()
        self._rebuild_sections()
        # Перший запуск: одразу вкладка «Пошук» з полем введення
        self.goto_key("search", announce=False)
        wx.CallLater(500, self._startup_sequence)

    def _startup_sequence(self):
        """Спочатку режим (запитати чи взяти з налаштувань) і оголошення, у якому режимі програма,
        і лише потім - поле пошуку та решта."""
        ms = self.settings["mode_start"]
        if ms == "ask":
            self._ask_mode()
        elif ms in ("audio", "video"):
            self.set_mode(ms == "video", announce=False, restart=False)
        self.goto_key("search", announce=False)
        self.say(("Відеорежим. " if self.video_mode else "Аудіорежим. ") + START_PROMPT)
        wx.CallLater(700, self.offer_components)
        if self.player is None and not components.missing():
            wx.CallLater(3500, self.say, self.player_error)
        if self.settings["startup_resume"] != "off":
            wx.CallLater(2500, self._startup_offer)
        if self.settings.has_account():
            wx.CallLater(2000, self.refresh_notif_count, True)
            wx.CallLater(6000, self._refresh_subscribed)

    def apply_theme(self):
        """Світла, темна або як у Windows - за налаштуванням «Вигляд вікна»."""
        try:
            theme.apply(self, self.settings["theme"])
            self._root.Layout()
        except Exception:  # noqa: BLE001
            log.debug("apply_theme", exc_info=True)

    def _startup_offer(self):
        if self.current is None and self.player is not None:
            self.offer_resume(auto=self.settings["startup_resume"] == "auto")

    # ---------- побудова ----------
    def _build_ui(self):
        root = wx.Panel(self, style=wx.CLIP_CHILDREN)

        # Верхня панель, як на YouTube: назва, вкладки зі значками, під ними - рядок пошуку.
        # З клавіатури: Tab / Shift+Tab перемикають лише «верх» (вкладки) і «низ» (голосовий пошук і
        # панель керування); по вкладках ходять стрілками вправо-вліво. Кнопки - і для миші.
        self.top_panel = wx.Panel(root)
        tp = self.top_panel
        brand = wx.StaticText(tp, label=APP_NAME)
        font = brand.GetFont()
        font.SetPointSize(font.GetPointSize() + 6)
        font.SetWeight(wx.FONTWEIGHT_BOLD)
        brand.SetFont(font)
        tabs_row = wx.BoxSizer(wx.HORIZONTAL)
        tabs_row.Add(brand, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 16)
        self.tab_buttons = {}
        for key, name in SECTIONS:
            tb = wx.Button(tp, label=name)
            tb.SetMinSize((-1, 34))
            bmp = make_icon("tab_" + key if key != "home" else "tab_home")
            if bmp:
                tb.SetBitmap(bmp)
                tb.SetBitmapMargins(6, 0)
            tb.SetToolTip(name)
            tb.Bind(wx.EVT_BUTTON, lambda e, k=key: self.goto_key(k))
            self._no_keyboard_focus(tb)
            tabs_row.Add(tb, 0, wx.RIGHT, 6)
            self.tab_buttons[key] = tb
        # Невидимий «вказівник» вкладок для клавіатури й зчитувача: Left / Right (і Up / Down)
        # перемикають вкладки, зчитувач каже «Вкладка Пошук, 1 з 6».
        self.section_lb = wx.ListBox(tp, choices=[], style=wx.LB_SINGLE, size=(1, 1))
        self.section_lb.SetName("Вкладки")
        self.section_lb.Bind(wx.EVT_LISTBOX, self._on_section_select)
        tabs_row.Add(self.section_lb, 0)

        search_label = wx.StaticText(tp, label="Пошук:")
        self.search_ctrl = wx.TextCtrl(tp, style=wx.TE_PROCESS_ENTER)
        self.search_ctrl.SetName("Пошук")
        self.search_ctrl.SetHint("Що шукати на YouTube")
        self.search_ctrl.Bind(wx.EVT_TEXT_ENTER, lambda e: self.do_search(self.search_ctrl.GetValue()))
        search_btn = wx.Button(tp, label="Шукати")
        search_btn.Bind(wx.EVT_BUTTON, lambda e: self.do_search(self.search_ctrl.GetValue()))
        self._no_keyboard_focus(search_btn)
        search_row = wx.BoxSizer(wx.HORIZONTAL)
        search_row.Add(search_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        search_row.Add(self.search_ctrl, 1, wx.RIGHT, 6)
        search_row.Add(search_btn, 0)
        top = wx.BoxSizer(wx.VERTICAL)
        top.Add(tabs_row, 0, wx.EXPAND)
        top.Add(search_row, 0, wx.EXPAND | wx.TOP, 6)
        tp.SetSizer(top)

        self.stack = wx.Panel(root)
        self.panels = {
            "search": ListPanel(self.stack, self, "Пошук", filter_blocked=True),
            "home": ListPanel(self.stack, self, "Головна", filter_blocked=True),
            "recs": ListPanel(self.stack, self, "Домашня сторінка", filter_blocked=True),
            "subs": ListPanel(self.stack, self, "Підписки", modes=[
                ("Канали", self._channels_loader),
                ("Нові відео", lambda: youtube.subscriptions(self.settings))]),
            "notif": ListPanel(self.stack, self, "Сповіщення"),
            "you": ListPanel(self.stack, self, "Ви", with_count=False),
        }
        self.search, self.home, self.recs = self.panels["search"], self.panels["home"], self.panels["recs"]
        self.subs, self.notif, self.you = self.panels["subs"], self.panels["notif"], self.panels["you"]
        self.notif.after_load = self._notif_loaded
        self.subs.after_load = self._subs_loaded
        ss = wx.BoxSizer(wx.VERTICAL)
        for p in self.panels.values():
            ss.Add(p, 1, wx.EXPAND)
            p.Hide()
        self.stack.SetSizer(ss)

        body = wx.BoxSizer(wx.HORIZONTAL)
        body.Add(self.stack, 1, wx.EXPAND)

        # Нижня панель плеєра. Назва видна завжди. Панель керування (позиція, гучність, кнопки)
        # є лише у відеорежимі й зникає під час перегляду, поки не натиснеш будь-яку клавішу.
        self.now_label = wx.StaticText(root, label="Зараз нічого не грає")
        nfont = self.now_label.GetFont()
        nfont.SetWeight(wx.FONTWEIGHT_BOLD)
        self.now_label.SetFont(nfont)
        self.controls = wx.Panel(root)
        cp = self.controls
        self.seek = wx.Slider(cp, value=0, minValue=0, maxValue=1000, style=wx.SL_HORIZONTAL)
        self.seek.SetName("Позиція відтворення")
        self.seek.Bind(wx.EVT_SCROLL_THUMBTRACK, lambda e: setattr(self, "_seeking", True))
        self.time_label = wx.StaticText(cp, label="0:00 / 0:00")
        self.vol = wx.Slider(cp, value=int(self.settings["volume"]), minValue=0, maxValue=100,
                             style=wx.SL_HORIZONTAL, size=(140, -1))
        self.vol.SetName("Гучність")
        self.vol.Bind(wx.EVT_SLIDER, self._on_volume_slider)
        # Нижня панель - лише для миші (зрячі). З клавіатури повзунки недоступні: інакше стрілки у
        # повноекранному відео змінювали б гучність чи перемотку, а незрячим лишаються вкладки зверху.
        self._no_keyboard_focus(self.seek)
        self._no_keyboard_focus(self.vol)
        self.seek.Bind(wx.EVT_SCROLL_CHANGED, self._on_seek_slider)
        self.vol.Bind(wx.EVT_SCROLL_CHANGED, lambda e: wx.CallAfter(self._release_panel_focus))
        timeline = wx.BoxSizer(wx.HORIZONTAL)
        timeline.Add(self.seek, 1, wx.RIGHT, 8)
        timeline.Add(self.time_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 16)
        timeline.Add(wx.StaticText(cp, label="Гучність:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 6)
        timeline.Add(self.vol, 0)

        bar = wx.WrapSizer(wx.HORIZONTAL)
        self.ctrl_buttons = []           # кнопки керування (з клавіатури лише у відеорежимі)
        self.play_btn = None
        for label, action, icon in (("Голосовий пошук", "voice_search", "mic"),
                                    ("Попередній", "prev_track", "prev"),
                                    ("Пауза / відтворення", "play_pause", "play_red"),
                                    ("Наступний", "next_track", "next"), ("Зупинити", "stop", "stop"),
                                    ("Повний екран", "fullscreen", "fullscreen"),
                                    ("Якість", "video_quality", "quality"),
                                    ("Режим", "toggle_mode", "mode"),
                                    ("Еквалайзер", "equalizer", "eq"),
                                    ("Завантажити...", "download_dialog", "download")):
            b = wx.Button(cp, label=label)
            b.SetMinSize((-1, 34))
            bmp = make_icon(icon)
            if bmp:
                b.SetBitmap(bmp)              # значок лише для зору; назву кнопки читає зчитувач
                b.SetBitmapMargins(6, 0)
            b.Bind(wx.EVT_BUTTON, lambda e, a=action: (self.perform(a), wx.CallAfter(self._release_panel_focus)))
            self._no_keyboard_focus(b)
            key = next((d for aid, _l, d, _g in ACTIONS if aid == action), "")
            b.SetToolTip(label + (" (%s)" % display_combo(key) if key else ""))
            bar.Add(b, 0, wx.RIGHT | wx.BOTTOM, 6)
            if action == "voice_search":
                self.voice_btn = b
            else:
                self.ctrl_buttons.append(b)
            if action == "play_pause":
                self.play_btn = b
        csz = wx.BoxSizer(wx.VERTICAL)
        csz.Add(timeline, 0, wx.EXPAND)
        csz.Add(bar, 0, wx.TOP, 6)
        cp.SetSizer(csz)
        self.info_label = wx.StaticText(root, label="")

        # Відеопанель: сюди mpv малює картинку (видима лише у відеорежимі)
        self.video_panel = wx.Panel(root, style=wx.CLIP_CHILDREN)
        self.video_panel.SetBackgroundStyle(wx.BG_STYLE_CUSTOM)
        self.video_panel.Bind(wx.EVT_ERASE_BACKGROUND, lambda e: None)    # не затираємо картинку плеєра
        self.video_panel.SetBackgroundColour(wx.BLACK)
        self.video_panel._keep_colours = True
        self.video_panel.SetMinSize((320, 180))
        self.video_panel.Hide()

        # усе, що ховається під час перегляду відео, і те, що є лише у відеорежимі
        self._chrome = [self.top_panel, self.stack, self.now_label, self.controls, self.info_label]
        self._video_only = [self.info_label]
        self._root = root

        s = wx.BoxSizer(wx.VERTICAL)
        s.Add(self.top_panel, 0, wx.EXPAND | wx.ALL, 8)
        s.Add(body, 1, wx.EXPAND | wx.LEFT | wx.RIGHT, 4)
        s.Add(self.video_panel, 2, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)
        s.Add(self.now_label, 0, wx.LEFT | wx.RIGHT | wx.TOP, 10)
        s.Add(self.controls, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 10)
        s.Add(self.info_label, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM | wx.TOP, 10)
        root.SetSizer(s)

    @staticmethod
    def _no_keyboard_focus(win):
        """Кнопка лише для миші: Tab її пропускає (з клавіатури є клавіші й зони Tab)."""
        try:
            win.DisableFocusFromKeyboard()
        except Exception:  # noqa: BLE001
            pass

    # ---------- клавіатурні зони: верх (вкладки) і низ (голосовий пошук, панель керування) ----------
    def _bottom_nav(self) -> list:
        """Що доступно з клавіатури внизу: лише голосовий пошук. Кнопки й повзунки панелі керування -
        для миші (зрячі): з клавіатури є гарячі клавіші."""
        return [self.voice_btn]

    def _release_panel_focus(self):
        """Після дії мишею на панелі керування фокус не лишається на кнопці чи повзунку:
        інакше стрілки або Enter змінювали б гучність, перемотку чи натискали кнопку."""
        try:
            f = self.FindFocus()
            if f is self.seek or f is self.vol or f in self.ctrl_buttons:
                # SetFocus() рамки повертає фокус на останній елемент (ту саму кнопку), тому - на вкладки
                self.section_lb.SetFocus()
        except RuntimeError:
            pass

    def _focus_zone(self) -> str:
        f = self.FindFocus()
        if f is self.section_lb:
            return "top"
        if f in [self.voice_btn] + self.ctrl_buttons:
            return "bottom"
        return "content"

    def _go_top(self):
        self.section_lb.SetFocus()
        self._say_tab()

    def _go_bottom(self):
        nav = self._bottom_nav()
        nav[min(self._bottom_idx, len(nav) - 1)].SetFocus()

    def _tab_phrase(self, key: str) -> str:
        name = SECTION_NAMES[key]
        if key == "notif" and self.notif_unseen > 0:
            name += ", нових: %d" % self.notif_unseen
        return "Вкладка %s, %d з %d" % (name, self.visible.index(key) + 1, len(self.visible))

    def _say_tab(self):
        if self.current_key in self.visible:
            self.say(self._tab_phrase(self.current_key))

    def _bottom_move(self, delta: int):
        nav = self._bottom_nav()
        f = self.FindFocus()
        i = nav.index(f) if f in nav else 0
        self._bottom_idx = (i + delta) % len(nav)
        nav[self._bottom_idx].SetFocus()

    def _tab_move(self, delta: int):
        """Left / Right на вкладках: перейти на сусідню вкладку й назвати її."""
        i = self.visible.index(self.current_key) if self.current_key in self.visible else 0
        key = self.visible[(i + delta) % len(self.visible)]
        self._show_section(key)
        if self._lazy:
            self._lazy.Stop()
        if key not in self._loaded:
            self._lazy = wx.CallLater(700, self._lazy_load, key)
        self._say_tab()

    def _set_play_icon(self, playing: bool):
        """Зелена «грає», червона - пауза або зупинено."""
        if self.play_btn is None or self._ui_cache.get("play_icon") == playing:
            return
        self._ui_cache["play_icon"] = playing
        bmp = make_icon("play_green" if playing else "play_red")
        if bmp:
            self.play_btn.SetBitmap(bmp)

    # ---------- панель плеєра: позиція і гучність ----------
    def _on_seek_slider(self, _e):
        self._seeking = False
        p = self.player
        if p and p.loaded:
            dur = p.duration or (self.current.duration if self.current else 0)
            if dur:
                p.seek_to(self.seek.GetValue() / 1000.0 * dur)

    def _on_volume_slider(self, _e):
        if self.player:
            self.settings["volume"] = self.player.set_volume(self.vol.GetValue())

    def update_player_ui(self):
        """Оновлює повзунок позиції, час і гучність (викликається таймером)."""
        p = self.player
        if not (p and p.loaded and self.current):
            text, pos_val = "0:00 / 0:00", 0
        else:
            dur = p.duration or self.current.duration or 0
            text = "%s / %s" % (fmt_time(p.position), fmt_time(dur))
            pos_val = int(max(0.0, min(1.0, p.position / dur)) * 1000) if dur else 0
        if self._ui_cache.get("time") != text:
            self._ui_cache["time"] = text
            self.time_label.SetLabel(text)
        if not self._seeking and self._ui_cache.get("pos") != pos_val:
            self._ui_cache["pos"] = pos_val
            self.seek.SetValue(pos_val)
        self._set_play_icon(bool(p and p.loaded and not p.paused))
        vol = int(p.volume) if p else int(self.settings["volume"])
        if self._ui_cache.get("vol") != vol:
            self._ui_cache["vol"] = vol
            self.vol.SetValue(vol)

    def build_menus(self):
        mb = wx.MenuBar()
        groups = {}
        for aid, label, _d, group in ACTIONS:
            groups.setdefault(group, []).append((aid, label))
        self._menu_actions = {}
        for group, acts in groups.items():
            m = wx.Menu()
            for aid, label in acts:
                key = self.keymap.key_of(aid)
                it = m.Append(wx.ID_ANY, "%s (%s)" % (label, display_combo(key)) if key else label)
                self._menu_actions[it.GetId()] = aid
            mb.Append(m, group)
        file_menu = wx.Menu()
        file_menu.Append(wx.ID_EXIT, "Вихід")
        mb.Append(file_menu, "Програма")
        old = self.GetMenuBar()
        self.SetMenuBar(mb)
        if old:
            old.Destroy()

    def _on_menu(self, e):
        if e.GetId() == wx.ID_EXIT:
            self.Close()
            return
        aid = self._menu_actions.get(e.GetId())
        if aid:
            self.perform(aid)
        else:
            e.Skip()

    # ---------- озвучення ----------
    VERBOSITY_LIMIT = {"full": 99, "normal": 2, "minimal": 1}

    def _say_allowed(self, detail: int) -> bool:
        return detail < self.VERBOSITY_LIMIT.get(self.settings["verbosity"], 99)

    def say(self, text, interrupt=True, detail=0):
        """detail: 0 - головне (чути завжди), 1 - дрібне пояснення (немає в режимі «Коротко»),
        2 - другорядне (немає в режимах «Звичайно» й «Коротко»)."""
        if not self._say_allowed(detail):
            log.info("say (пропущено, детальність): %s", text)
            return
        if youtube.emoji_mode() == "words":
            text = emoji.to_words(text)            # режим «словами»: називаємо емодзі
        log.info("say: %s", text)
        self.speaker.say(text, interrupt)
        try:
            self.SetStatusText(text)
        except RuntimeError:
            pass
        pl = getattr(self, "player", None)
        if getattr(self, "video_mode", False) and pl and pl.loaded and len(text) <= 140:
            pl.osd(text)          # зрячі бачать ті самі підказки поверх відео

    # ---------- клавіші ----------
    @staticmethod
    def _text_safe(combo: str) -> bool:
        key = combo.split("+")[-1]
        return (combo.startswith("Alt") or bool(re.fullmatch(r"F\d+", key))
                or bool(re.fullmatch(r"Ctrl\+\d", combo)))

    def on_char_hook(self, e):
        combo = event_to_combo(e.GetKeyCode(), e.ControlDown(), e.AltDown(), e.ShiftDown(),
                               e.GetUnicodeKey())
        if combo is None:
            e.Skip()
            return
        was_hidden = self._chrome_hidden   # кнопки були сховані: дивимось відео, стрілки мають перемотувати
        self._note_activity()          # будь-яка клавіша повертає кнопки, сховані під час відео
        focus = self.FindFocus()
        in_text = isinstance(focus, (wx.TextCtrl, wx.ComboBox))

        # Панель керування (кнопки й повзунки) - лише для миші. Якщо фокус там лишився після кліку,
        # Пробіл чи Enter натискали б кнопку, наприклад «Повний екран», і вікно саме перемикалось би.
        if focus is self.seek or focus is self.vol or focus in self.ctrl_buttons:
            self.section_lb.SetFocus()
            if combo in ("Space", "Enter"):
                return

        # У повноекранному режимі Backspace виходить з нього
        if combo == "Backspace" and self.IsFullScreen() and not in_text:
            self._set_fullscreen(False)
            return
        # Escape - завжди пауза / відтворення (у меню й діалогах Escape закриває їх, як звичайно)
        if combo == "Escape":
            act = self.keymap.action_for("Escape")
            if act:
                self.perform(act)
            else:
                e.Skip()
            return
        # Пробіл - як скрізь у Windows: натискає кнопку, у полі тексту вводить пробіл
        if combo == "Space":
            e.Skip()
            return
        # Tab / Shift+Tab: лише між верхом (вкладки) і низом (голосовий пошук, панель керування)
        if combo in ("Tab", "Shift+Tab"):
            zone = self._focus_zone()
            if combo == "Tab":
                self._go_top() if zone == "bottom" else self._go_bottom()
            else:
                self._go_bottom() if zone == "top" else self._go_top()
            return
        # Стрілки вправо-вліво: по вкладках зверху і по кнопках знизу
        if combo in ("Left", "Right"):
            zone = self._focus_zone()
            d = 1 if combo == "Right" else -1
            if zone == "top" and not was_hidden:
                self._tab_move(d)
                return
            if zone == "bottom" and not was_hidden:
                self._bottom_move(d)
                return
        # З поля пошуку стрілка вниз - до списку результатів
        if combo == "Down" and focus is self.search_ctrl and self.search.items:
            self.search.lc.SetFocus()
            return

        # Enter - вибір: на кнопці натискає її, на списку вкладок переходить до вмісту
        if combo == "Enter":
            if isinstance(focus, wx.Button):
                ev = wx.CommandEvent(wx.wxEVT_BUTTON, focus.GetId())
                ev.SetEventObject(focus)
                focus.GetEventHandler().ProcessEvent(ev)
                return
            if focus is self.section_lb:
                self.goto_key(self.current_key, announce=False)
                return
            e.Skip()
            return
        if combo in ("Ctrl+Tab", "Ctrl+Shift+Tab"):
            self.cycle_section(1 if combo == "Ctrl+Tab" else -1)
            return
        action = self.keymap.action_for(combo) or MEDIA_KEYS.get(combo)
        if not action:
            e.Skip()
            return
        if in_text:
            if not self._text_safe(combo):
                e.Skip()
                return
        elif is_plain(combo) and not (isinstance(focus, (wx.ListCtrl, wx.ListBox)) or was_hidden
                                      or focus is None or focus is self or focus is self.video_panel):
            e.Skip()                       # звичайні клавіші діють у списку й на картинці відео, не на кнопках
            return
        self.perform(action)

    def perform(self, action: str):
        try:
            if action.startswith("tab_"):
                self.goto_key(action[4:])
                return
            fn = getattr(self, "act_" + action, None)
            if fn:
                fn()
        except Exception:  # noqa: BLE001
            log.exception("Помилка дії %s", action)
            self.say("Сталася помилка. Подробиці в data\\youstream.log")

    # ---------- вкладки ----------
    def _section_label(self, key: str) -> str:
        name = SECTION_NAMES[key]
        if key == "notif" and self.notif_unseen > 0:
            name += " (%d)" % self.notif_unseen
        return name

    def _rebuild_sections(self):
        """Оновлює список вкладок: «Сповіщення» лише при вході в акаунт."""
        has = self.settings.has_account()
        self.visible = [k for k, _n in SECTIONS if k != "notif" or has]
        self.section_lb.Set([self._section_label(k) for k in self.visible])
        if self.current_key not in self.visible:
            self.current_key = "search"
        self.section_lb.SetSelection(self.visible.index(self.current_key))
        self.tab_buttons["notif"].Show(has)
        self._restyle_tabs()
        self.top_panel.Layout()

    def _restyle_tabs(self):
        """Поточна вкладка виділена жирним; на «Сповіщення» видно кількість нових."""
        for key, btn in self.tab_buttons.items():
            bold = key == self.current_key
            label = self._section_label(key)
            cache = self._ui_cache.setdefault("tabs", {})
            if cache.get(key) == (bold, label):
                continue
            cache[key] = (bold, label)
            f = btn.GetFont()
            f.SetWeight(wx.FONTWEIGHT_BOLD if bold else wx.FONTWEIGHT_NORMAL)
            btn.SetFont(f)
            btn.SetLabel(label)
        self.top_panel.Layout()

    def _update_notif_label(self):
        if "notif" in self.visible:
            self.section_lb.SetString(self.visible.index("notif"), self._section_label("notif"))
        self._restyle_tabs()

    def _show_section(self, key: str):
        self.current_key = key
        for k, p in self.panels.items():
            if k == key:
                p.Show()
            else:
                p.Hide()
        self.stack.Layout()
        if key in self.visible:
            self.section_lb.SetSelection(self.visible.index(key))
        self._restyle_tabs()

    def goto_key(self, key: str, focus: bool = True, announce: bool = True):
        if key not in self.visible:
            self.say("Вкладка «%s» доступна після входу в акаунт YouTube. Налаштуйте його в Налаштуваннях."
                     % SECTION_NAMES.get(key, key))
            return
        self._show_section(key)
        if announce:
            self.say(self._tab_phrase(key))
        self._ensure_loaded(key, focus=focus, announce=announce)
        if focus:
            (self.search_ctrl if key == "search" else self.panels[key].lc).SetFocus()

    def _on_section_select(self, _e):
        """Стрілки у списку вкладок: показуємо вкладку, не забираючи фокус. Читає зчитувач."""
        i = self.section_lb.GetSelection()
        if not (0 <= i < len(self.visible)):
            return
        key = self.visible[i]
        if key == self.current_key:
            return
        self._show_section(key)
        if self._lazy:
            self._lazy.Stop()
        if key not in self._loaded:        # не вантажимо, поки користувач просто «проходить» вкладками
            self._lazy = wx.CallLater(700, self._lazy_load, key)

    def _lazy_load(self, key):
        if self.current_key == key:
            self._ensure_loaded(key, focus=False, announce=False)

    def cycle_section(self, delta: int):
        i = self.visible.index(self.current_key) if self.current_key in self.visible else 0
        self.goto_key(self.visible[(i + delta) % len(self.visible)],
                      focus=not isinstance(self.FindFocus(), wx.ListBox))

    def _ensure_loaded(self, key: str, focus: bool, announce: bool):
        if key in self._loaded:
            return
        if key == "recs":
            self._loaded.add(key)
            self.load_recs(focus=focus, announce=announce)
        elif key == "subs":
            self._loaded.add(key)
            label, loader = self.subs.modes[0]
            # кількість каналів і нових відео озвучує _subs_loaded одним повідомленням (після завантаження):
            # раніше список казав кількість елементів на початку, а потім ще раз про нові відео
            self.subs.load(loader, label, announce=False, focus=focus)
        elif key == "notif":
            self._loaded.add(key)
            self.load_notifs(focus=focus, announce=announce)

    def current_panel(self):
        return self.panels[self.current_key]

    def on_panel_failed(self, panel):
        """Вкладка не завантажилась (наприклад, не було входу в акаунт): наступного разу вантажимо знову,
        а не лишаємо «завантаженою» з помилкою, поки не натиснуть F6."""
        for key in ("subs", "notif", "recs"):
            if self.panels.get(key) is panel:
                self._loaded.discard(key)

    # ---------- головна (розділи) і домашня сторінка ----------
    def show_home_menu(self):
        items = [Item(title=c[0], kind="menu", extra={"run": lambda p, i=i: self.open_category(p, i)})
                 for i, c in enumerate(CATEGORIES)]
        self.home.show_items(items, "Головна")

    def open_category(self, panel, index: int):
        query, sp, name = category_query(index, self.settings["category_hint"])
        panel.load(lambda: youtube.search(query, self.settings, sp=sp), name, push=True)

    def load_recs(self, focus=True, announce=True):
        self.recs.load(lambda: youtube.recommendations(self.settings, list(self.store.history),
                                                       self.store.is_blocked),
                       "Домашня сторінка", focus=focus, announce=announce)

    # ---------- сповіщення ----------
    def load_notifs(self, focus=True, announce=True):
        self.notif.load(self._notif_loader, "Сповіщення", focus=focus, announce=announce)

    def _notif_loader(self):
        try:
            rows = self.account.notifications()
            items = []
            for n in rows:
                if not n["video_id"]:
                    continue
                items.append(Item(id=n["video_id"], title=("Нове: " if not n["read"] else "") + n["title"],
                                  channel=n["when"], kind="video",
                                  url="https://www.youtube.com/watch?v=" + n["video_id"]))
            if items or rows:
                return items
        except youtube.YtError as e:
            log.info("Сповіщення YouTube недоступні, показую нові відео підписок: %s", e)
        items = youtube.subscriptions(self.settings)
        for it in items:
            if it.kind == "video" and self.store.unseen_count([it.id]):
                it.title = "Нове: " + it.title
        return items

    def _notif_loaded(self, items):
        new = sum(1 for it in items if (it.title or "").startswith("Нове:"))
        self.store.mark_seen([it.id for it in items if it.kind == "video"])
        self.notif_unseen = 0
        self._update_notif_label()
        if items:
            self.say("Сповіщень: %d, нових: %d" % (len(items), new), interrupt=False)
        else:
            self.say("Сповіщень немає", interrupt=False)

    def refresh_notif_count(self, announce: bool = False):
        if not self.settings.has_account():
            return

        def work():
            n = None
            try:
                n = self.account.unseen_count()
            except youtube.YtError as e:
                log.info("Лічильник сповіщень: %s", e)
                try:       # запасний варіант: нові відео підписок
                    ids = [it.id for it in youtube.subscriptions(self.settings) if it.kind == "video"]
                    if not self.store.seen_ids:
                        self.store.mark_seen(ids)      # перший запуск: все вважаємо баченим
                    n = self.store.unseen_count(ids)
                except youtube.YtError:
                    n = None
            except Exception:  # noqa: BLE001
                log.exception("unseen_count")
            if n is not None:
                wx.CallAfter(self._set_notif, n, announce)

        threading.Thread(target=work, daemon=True).start()
        wx.CallLater(NOTIF_REFRESH_MS, self.refresh_notif_count, False)

    def _set_notif(self, n: int, announce: bool):
        if self.current_key == "notif":
            n = 0       # вкладка відкрита - усе прочитано; кількість скаже сам список, коли завантажиться
        self.notif_unseen = n
        self._update_notif_label()
        if announce and n > 0:
            self.say("Непрочитаних сповіщень: %d" % n, interrupt=False)

    def on_count_changed(self, n: int):
        self.settings["results_count"] = n
        self.settings.save()
        for p in self.panels.values():
            p.sync_count()
        self.say("Елементів у списку: %d" % n)
        # кілька швидких натискань - одне оновлення списку, коли користувач зупинився
        if self._count_timer is not None:
            self._count_timer.Stop()
        self._count_timer = wx.CallLater(1000, self._refresh_after_count)

    def _refresh_after_count(self):
        self._count_timer = None
        p = self.current_panel()
        if p.loader and p is not self.you:
            p.refresh()

    def act_count_next(self):
        self.on_count_changed(next_count(self.settings["results_count"], 1))

    def act_count_prev(self):
        self.on_count_changed(next_count(self.settings["results_count"], -1))

    # ---------- пошук ----------
    def do_search(self, query: str):
        query = (query or "").strip()
        if not query:
            self.say("Введіть запит")
            return
        self.search.stack.clear()
        self.search_ctrl.SetValue(query)
        self._show_section("search")
        self._loaded.add("search")
        self.search.load(lambda: youtube.search(query, self.settings), "Результати пошуку: " + query)

    def act_focus_search(self):
        self.goto_key("search", focus=False, announce=False)
        self.search_ctrl.SetFocus()
        self.search_ctrl.SelectAll()
        self.say(START_PROMPT)

    def act_voice_search(self):
        if self._voice_stop is not None:
            self._voice_stop.set()
            self.say("Голосовий пошук зупинено")
            return
        stop = threading.Event()
        self._voice_stop = stop
        self.say("Говоріть після сигналу")

        def work():
            time.sleep(1.6)   # щоб мікрофон не записав голос зчитувача
            if stop.is_set():
                wx.CallAfter(self._voice_done, None, "")
                return
            self._beep()
            time.sleep(0.15)
            try:
                text = voice.listen(self.settings["voice_lang"], stop)
                wx.CallAfter(self._voice_done, text, "")
            except voice.VoiceError as e:
                wx.CallAfter(self._voice_done, None, str(e))
            except Exception as e:  # noqa: BLE001
                log.exception("voice")
                wx.CallAfter(self._voice_done, None, "Помилка голосового пошуку: %s" % e)

        threading.Thread(target=work, daemon=True).start()

    @staticmethod
    def _beep():
        try:
            import winsound
            winsound.Beep(880, 160)
        except Exception:  # noqa: BLE001 - не Windows або немає звукової карти
            wx.CallAfter(wx.Bell)

    def _voice_done(self, text, err):
        self._voice_stop = None
        if text:
            self.say("Шукаю: " + text)
            self.do_search(text)
        elif err:
            self.say(err)

    # ---------- елементи списків ----------
    def activate_item(self, panel: ListPanel, item: Item):
        if item.kind == "menu":
            item.extra["run"](panel)
        elif item.kind in ("video", "local"):
            idx = next((i for i, x in enumerate(panel.items) if x is item), 0)
            self.play_list(panel.items, idx)
        elif item.kind in ("channel", "playlist"):
            self.open_item(panel, item)

    def open_item(self, panel, item):
        def loader():
            items = youtube.open_container(item, self.settings)
            if item.kind == "channel":
                # канал відкрито - його відео вважаються переглянутими (лічильник нових скидається)
                self.store.mark_seen([i.id for i in items if i.id])
                item.extra["new"] = 0
                item.extra["published"] = ""
            return items

        panel.load(loader, item.title, push=True)

    # ---------- підписки: нові відео по каналах ----------
    def _channels_loader(self):
        """Канали, на які ви підписані, з лічильником нових відео (спершу ті, де є нові)."""
        chans = youtube.subscribed_channels(self.settings)
        self._subs_error = ""
        try:
            feed = youtube.list_url(":ytsubs", self.settings, max(100, int(self.settings["results_count"])),
                                    stream=False)
        except YtError as e:
            feed = []
            self._subs_error = str(e)
            log.warning("Стрічка підписок недоступна: %s", e)
        self.track_upcoming(feed)
        known = set(self.store.seen_ids) | {h.get("id") for h in self.store.history}
        by_id, by_name = {}, {}
        for v in feed:
            if v.kind != "video" or not v.id or v.id in known:
                continue
            cid = (v.extra or {}).get("channel_id", "")
            if cid:
                by_id[cid] = by_id.get(cid, 0) + 1
            name = (v.channel or "").split(" · ")[0].strip().casefold()
            by_name[name] = by_name.get(name, 0) + 1
        self._subbed = {self._chan_key(c.title) for c in chans if c.title}
        for c in chans:
            # за кодом каналу - точно; за назвою - запасний варіант, якщо коду немає
            cid = (c.extra or {}).get("channel_id", "")
            n = max(by_id.get(cid, 0) if cid else 0, by_name.get((c.title or "").strip().casefold(), 0))
            c.extra["new"] = n
            c.extra["published"] = ("нових відео: %d" % n) if n else ""
            if n:
                c.channel = "нових відео: %d, %s" % (n, c.channel)
        chans.sort(key=lambda c: -c.extra.get("new", 0))      # стабільно: нові - нагору
        return chans

    def _subs_loaded(self, items):
        chans = [i for i in items if i.kind == "channel"]
        if not chans:
            return
        if getattr(self, "_subs_error", ""):
            self.say("Підписки: каналів %d. Порахувати нові відео не вдалося: %s" % (
                len(chans), self._subs_error[:120]), interrupt=False)
            return
        with_new = [c for c in chans if c.extra.get("new")]
        head = "Підписки: каналів %d. " % len(chans)
        if with_new:
            total = sum(c.extra["new"] for c in with_new)
            self.say(head + "Нових відео: %d, на каналах: %d" % (total, len(with_new)), interrupt=False)
        else:
            self.say(head + "Нових відео немає", interrupt=False)

    def _target_item(self):
        p = self.current_panel()
        if isinstance(self.FindFocus(), wx.ListCtrl):
            it = p.selected_item()
            if it and it.kind in ("video", "local"):
                return it
        return self.current

    def act_stop(self):
        if self.player:
            self._save_position()
            self.player.stop()
            self.current = None
            self.say("Зупинено")

    def act_back(self):
        if self.IsFullScreen():
            self._set_fullscreen(False)
            return
        self.current_panel().back()

    def act_subs_mode(self):
        if self.current_key != "subs" or not self.subs.cycle_mode():
            self.say("Перемикання працює у вкладці Підписки")

    def act_refresh(self):
        p = self.current_panel()
        if p is self.you:
            self.show_you_menu()
            self.say("Оновлено")
        elif p is self.home and not p.stack:
            self.show_home_menu()
            self.say("Оновлено")
        elif p is self.search and not p.loader:
            self.say("Введіть запит і натисніть Enter")
        else:
            p.refresh()

    def act_add_queue(self):
        it = self.current_panel().selected_item()
        if it:
            self.add_to_queue(it)

    def act_add_playlist(self, item=None):
        it = item or self._target_item()
        if not it or it.kind != "video":
            self.say("Оберіть відео")
            return
        names = self.store.playlist_names()
        with wx.SingleChoiceDialog(self, "Додати «%s» до списку:" % it.title, "Мої списки",
                                   names + ["Створити новий список..."]) as d:
            if d.ShowModal() != wx.ID_OK:
                return
            sel = d.GetSelection()
        if sel >= len(names):
            with wx.TextEntryDialog(self, "Назва нового списку:", "Новий список") as t:
                if t.ShowModal() != wx.ID_OK or not t.GetValue().strip():
                    return
                name = t.GetValue().strip()
        else:
            name = names[sel]
        ok = self.store.add_to_playlist(name, it.to_dict())
        self.say(("Додано до списку «%s»" if ok else "Вже є у списку «%s»") % name)

    def act_open_channel(self, item=None):
        p = self.current_panel()
        it = item or (self._target_item() if not p.selected_item() else p.selected_item())
        if not it:
            return
        if it.kind in ("channel", "playlist"):
            self.open_item(p, it)
            return
        self.say("Шукаю канал")

        def work():
            try:
                ch = youtube.channel_of(it, self.settings)
            except YtError as e:
                wx.CallAfter(self.say, str(e))
                return
            wx.CallAfter(self.open_item, p, ch) if ch else wx.CallAfter(self.say, "Канал не знайдено")

        threading.Thread(target=work, daemon=True).start()

    # ---------- меню дій («Ще») ----------
    def act_more_menu(self):
        self.show_more_menu(self.current_panel())

    def show_more_menu(self, panel):
        it = panel.selected_item()
        if not it:
            self.say("Список порожній")
            return
        self.show_context_menu(panel, it)

    @staticmethod
    def _channel_name(item) -> str:
        if item.kind == "channel":
            return (item.title or "").strip()
        return (item.channel or "").split(" · ")[0].strip()

    def show_context_menu(self, panel, item):
        acts = []

        def add(label, fn):
            acts.append((label, fn))

        km = self.keymap.key_of
        idx = next((i for i, x in enumerate(panel.items) if x is item), 0)
        if item.kind in ("video", "local"):
            add("Відтворити", lambda: self.play_list(panel.items, idx))
            add("Додати в чергу", lambda: self.add_to_queue(item))
            if item.kind == "video":
                add("Зберегти в списку «%s»" % WATCH_LATER, lambda: self.save_watch_later(item))
                add("Зберегти у список відтворення...", lambda: self.act_add_playlist(item))
                add("Поділитися (копіювати посилання)", lambda: self._copy(item.url, "Посилання скопійовано. Можна ділитися."))
                add("Короткий опис (%s)" % km("description"), lambda: self.act_description(item))
                if self.current and (self.current.id or self.current.url) == (item.id or item.url):
                    add("Мова звуку відео... (%s)" % km("audio_track"), self.act_audio_track)
                    add("Субтитри: озвучувати / не озвучувати (%s)" % km("subs_toggle"), self.act_subs_toggle)
                add("Завантажити аудіо (%s)" % km("download_mp3"), lambda: self.download_audio(item))
                add("Завантажити відео (%s)" % km("download_mp4"), lambda: self.download_video(item))
                add("Завантажити з вибором якості... (%s)" % km("download_dialog"),
                    lambda: self.act_download_dialog(item))
                add("Перейти до каналу", lambda: self.act_open_channel(item))
                self._channel_menu_items(item, add)
                add("Лайк", lambda: self.rate(item, "like"))
                add("Дизлайк", lambda: self.rate(item, "dislike"))
                add("Прибрати оцінку", lambda: self.rate(item, "remove"))
                add("Коментарі (читати і писати)...", lambda: self.act_comments(item))
                add("Не цікавить", lambda: self.not_interested(panel, item))
                add("Не рекомендувати канал", lambda: self.block_channel(panel, item))
            else:
                add("Показати у папці", lambda: self._reveal(item.path))
                add("Видалити файл з диска...", lambda: self._delete_download(panel, item))
        elif item.kind in ("channel", "playlist"):
            add("Відкрити", lambda: self.open_item(panel, item))
            add("Поділитися (копіювати посилання)", lambda: self._copy(item.url, "Посилання скопійовано. Можна ділитися."))
            if item.kind == "channel":
                self._channel_menu_items(item, add)
            add("Не рекомендувати канал", lambda: self.block_channel(panel, item))
        elif item.kind == "menu":
            add("Відкрити", lambda: self.activate_item(panel, item))
            if item.extra.get("delete"):
                add("Видалити...", lambda: item.extra["delete"]())
        src = panel.source
        if src and src[0] == "playlist" and item.kind == "video":
            add("Видалити зі списку", lambda: self._remove_from_playlist(panel, src[1], item))
        if src and src[0] == "history" and item.kind in ("video", "local"):
            add("Прибрати з історії", lambda: self._remove_history(panel, item))
        add("Закрити меню (Backspace)", lambda: None)
        with ActionMenuDialog(self, [lbl for lbl, _fn in acts], "Дії: " + (item.title or "")[:60]) as dlg:
            ok = dlg.ShowModal() == wx.ID_OK
            idx = dlg.choice
        if ok and 0 <= idx < len(acts):
            wx.CallAfter(acts[idx][1])

    # ---------- дії акаунта та локальні дії над елементами ----------
    def _account_task(self, work, done_msg: str):
        """Виконує work() у фоні; озвучує done_msg або текст помилки."""
        if not self.settings.has_account():
            self.say("Потрібен вхід в акаунт. Налаштуйте його в розділі Ви, Налаштування.")
            return
        self.say("Виконую", interrupt=False)

        def run():
            try:
                work()
                wx.CallAfter(self.say, done_msg)
            except YtError as e:
                wx.CallAfter(self.say, str(e))
            except Exception as e:  # noqa: BLE001
                log.exception("Дія акаунта")
                wx.CallAfter(self.say, "Не вдалося виконати дію: %s" % e)

        threading.Thread(target=run, daemon=True).start()

    def rate(self, item, kind: str):
        if not item.id:
            self.say("Оберіть відео")
            return
        fn, msg = {"like": (self.account.like, "Лайк поставлено"),
                   "dislike": (self.account.dislike, "Дизлайк поставлено"),
                   "remove": (self.account.remove_like, "Оцінку прибрано")}[kind]
        self._account_task(lambda: fn(item.id), msg)

    # ---------- стан каналу: підписка і сповіщення (для меню дій) ----------
    @staticmethod
    def _chan_key(name: str) -> str:
        return (name or "").strip().casefold()

    def _chan_flags(self, item):
        """(підписані?, сповіщення увімкнені?): True / False, або None, якщо поки невідомо."""
        key = self._chan_key(self._channel_name(item))
        st = self.chan_state.get(key, {})
        sub = (key in self._subbed) if self._subbed is not None else st.get("sub")
        notify = st.get("notify")
        if sub is False:
            notify = None
        return sub, notify

    def _save_chan_state(self, item, sub=None, notify=None):
        key = self._chan_key(self._channel_name(item))
        if not key:
            return
        st = self.chan_state.setdefault(key, {})
        if sub is not None:
            st["sub"] = sub
            if self._subbed is not None:
                (self._subbed.add if sub else self._subbed.discard)(key)
            if not sub:
                st["notify"] = False
        if notify is not None:
            st["notify"] = notify
        try:
            write_json(os.path.join(self.store.dir, "channels.json"), self.chan_state)
        except OSError:
            log.debug("channels.json", exc_info=True)

    def _refresh_subscribed(self):
        """У фоні дізнається, на які канали ви підписані (щоб меню не пропонувало зайвого)."""
        if not self.settings.has_account():
            return

        def work():
            try:
                chans = youtube.subscribed_channels(self.settings)
            except Exception:  # noqa: BLE001
                return
            names = {self._chan_key(c.title) for c in chans if c.title}
            wx.CallAfter(self._set_subscribed, names)

        threading.Thread(target=work, daemon=True).start()

    def _set_subscribed(self, names: set):
        self._subbed = names

    def channel_action(self, item, what: str):
        def work():
            cid, _name, url = youtube.channel_info(item, self.settings)
            if not cid:
                cid = self.account.resolve_channel_id(url)
            if what in ("subscribe", "subscribe_notify"):
                self.account.subscribe(cid)
                self._save_chan_state(item, sub=True, notify=False)
                if what == "subscribe_notify":
                    self.account.set_channel_notifications(cid, True)
                    self._save_chan_state(item, notify=True)
            elif what == "unsubscribe":
                self.account.unsubscribe(cid)
                self._save_chan_state(item, sub=False)
            else:
                self.account.set_channel_notifications(cid, what == "notify_on")
                self._save_chan_state(item, sub=True, notify=(what == "notify_on"))

        msgs = {"subscribe": "Ви підписалися на канал", "unsubscribe": "Підписку скасовано",
                "subscribe_notify": "Ви підписалися на канал, сповіщення увімкнено",
                "notify_on": "Сповіщення каналу увімкнено", "notify_off": "Сповіщення каналу вимкнено"}
        self._account_task(work, msgs[what])

    def _channel_menu_items(self, item, add):
        """Пункти меню про канал: лише те, що має сенс для поточного стану підписки і сповіщень."""
        sub, notify = self._chan_flags(item)
        if sub is not True:
            add("Підписатися на канал", lambda: self.channel_action(item, "subscribe"))
            add("Підписатися і увімкнути сповіщення", lambda: self.channel_action(item, "subscribe_notify"))
        if sub is not False:
            add("Скасувати підписку на канал", lambda: self.channel_action(item, "unsubscribe"))
            if notify is not True:
                add("Увімкнути сповіщення каналу", lambda: self.channel_action(item, "notify_on"))
            if notify is not False:
                add("Вимкнути сповіщення каналу", lambda: self.channel_action(item, "notify_off"))

    def save_watch_later(self, item):
        if not item.id:
            self.say("Оберіть відео")
            return
        if self.settings.has_account():
            self._account_task(lambda: self.account.watch_later_add(item.id),
                               "Збережено в списку «%s» на YouTube" % WATCH_LATER)
            return
        ok = self.store.add_to_playlist(WATCH_LATER, item.to_dict())
        self.say(("Збережено в списку «%s»" if ok else "Уже є в списку «%s»") % WATCH_LATER +
                 ". Він у розділі Ви, Мої списки.")

    def not_interested(self, panel, item):
        self.store.block_video(item.id, item.title)
        panel.remove_items(lambda x: x.id == item.id)
        self.say("Добре, це відео більше не показуватиметься")

    def block_channel(self, panel, item):
        name = self._channel_name(item)
        if not name or name == "канал":
            self.say("Не вдалося визначити канал")
            return
        self.store.block_channel(name)
        panel.remove_items(lambda x: self.store.is_blocked(x))
        self.say("Канал «%s» більше не рекомендуватиметься" % name)

    def act_comments(self, item=None):
        it = item or self._target_item()
        if not it or it.kind != "video" or not it.id:
            self.say("Оберіть відео")
            return
        with CommentsDialog(self, self, it) as d:
            d.ShowModal()

    def _copy(self, text, msg="Посилання скопійовано"):
        if wx.TheClipboard.Open():
            wx.TheClipboard.SetData(wx.TextDataObject(text))
            wx.TheClipboard.Close()
            self.say(msg)

    def _reveal(self, path):
        try:
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        except OSError:
            self.say("Не вдалося відкрити папку")

    def _delete_download(self, panel, item):
        if wx.MessageBox("Видалити файл «%s» з диска?" % item.title, "Підтвердження",
                         wx.YES_NO | wx.ICON_WARNING, self) == wx.YES:
            self.store.remove_download(item.path, delete_file=True)
            self.open_downloads(panel, push=False)
            self.say("Файл видалено")

    def _remove_from_playlist(self, panel, name, item):
        self.store.remove_from_playlist(name, item.id)
        panel.show_items([Item.from_dict(d) for d in self.store.playlists.get(name, [])],
                         name, source=("playlist", name))
        self.say("Видалено зі списку")

    def _remove_history(self, panel, item):
        self.store.remove_history(item.id or item.path)
        self.open_history(panel, push=False)
        self.say("Прибрано з історії")

    # ---------- завантаження ----------
    def download(self, item, fmt: str, quality: str = "", force: bool = False):
        """F3 / F4 / Ctrl+D. Повторне натискання на тому самому файлі озвучує стан завантаження."""
        if not item:
            self.say("Немає що завантажувати")
            return
        if self._lic_guard():
            return
        if item.kind == "local":
            self.say("Цей файл уже завантажено")
            return
        if not item.url:
            self.say("Немає що завантажувати")
            return
        now = time.time()
        job = self.downloader.job_for(item, fmt)
        if job:
            if job.pressed_at and now - job.pressed_at < 1.5:
                # друге натискання одразу після першого - скасувати й прибрати частковий файл
                was_running = job.state == "running"
                self.downloader.cancel(job)
                if not was_running:
                    self.say("Завантаження скасовано: " + item.title)
                return
            job.pressed_at = now
            self.say(self.downloader.job_status(job) + " Щоб скасувати, швидко натисніть ще раз.")
            return
        failed = self.downloader.last_failed(item, fmt)
        if failed:
            failed.told_error = True
            self.say(failed.status_text() + " Натисніть ще раз, щоб спробувати знову.")
            return
        if not force:
            found = self.downloader.find_existing(item, fmt)
            if found:
                self.say("Цей файл уже є в папці завантажень: %s" % os.path.basename(os.path.dirname(found)))
                return
        job = self.downloader.add(item, fmt, quality, force)
        if job is not None:
            job.pressed_at = now           # швидке друге натискання одразу скасує
        self.say("У чергу завантажень додано: %s, %s. Папка: %s. Ще раз - стан, швидко двічі - скасувати." % (
            item.title, quality_label(fmt, quality), subdir_for(fmt)), detail=1)

    def download_audio(self, item):
        fmt, q = parse_spec(self.settings["dl_audio"])
        self.download(item, fmt, q)

    def download_video(self, item):
        self.download(item, "mp4", str(self.settings["dl_video_height"]))

    def act_download_mp3(self):
        it = self._target_item()
        self.download_audio(it) if it else self.say("Оберіть відео або увімкніть відтворення")

    def act_download_mp4(self):
        it = self._target_item()
        self.download_video(it) if it else self.say("Оберіть відео або увімкніть відтворення")

    def act_download_dialog(self, item=None):
        it = item or self._target_item()
        if not it or it.kind != "video":
            self.say("Оберіть відео або увімкніть відтворення")
            return
        with DownloadDialog(self, it.title, self.settings["last_dl_spec"]) as d:
            d.ShowModal()
            res = d.result()
        if not res:
            return
        spec, remember = res
        fmt, q = parse_spec(spec)
        self.settings["last_dl_spec"] = spec
        if remember:
            if fmt == "mp4":
                self.settings["dl_video_height"] = int(q)
            else:
                self.settings["dl_audio"] = spec
        self.settings.save()
        force = False
        if self.downloader.find_existing(it, fmt):
            if wx.MessageBox("Такий файл уже є в папці завантажень. Завантажити ще раз?", "Завантаження",
                             wx.YES_NO | wx.ICON_QUESTION, self) != wx.YES:
                return
            force = True
        self.download(it, fmt, q, force)
        if remember:
            self.say("Запам'ятовано для клавіші %s" % ("F4" if fmt == "mp4" else "F3"), interrupt=False)

    def _dl_event(self, kind, job):
        if kind == "started":
            self.say("Починаю завантаження: " + job.label(), interrupt=False, detail=1)
        elif kind == "done":
            self.say("Завантажено: %s. Папка: %s" % (job.label(), subdir_for(job.fmt)), interrupt=False)
        elif kind == "error":
            job.told_error = True
            self.say("Не вдалося завантажити: %s. %s Спробуйте пізніше." % (job.item.title, job.error),
                     interrupt=False)
        elif kind == "cancelled":
            self.say("Завантаження скасовано: %s.%s" % (
                job.item.title, " Частковий файл видалено." if job.removed else ""), interrupt=False)

    # ---------- вкладка «Ви» ----------
    def show_you_menu(self):
        def mk(title, run):
            return Item(title=title, kind="menu", extra={"run": run})

        def acct(loader, title):
            return lambda p: p.load(loader, title, push=True)

        s = self.settings
        items = [
            mk("Продовжити останнє", lambda p: self.act_resume_last()),
            mk("Недослухане (продовжити з місця зупинки)", lambda p: self.open_unfinished(p)),
            mk("Історія перегляду", lambda p: self.open_history(p)),
            mk("Завантаження", lambda p: self.open_downloads(p)),
            mk("Мої списки", lambda p: self.open_my_playlists(p)),
            mk("Історія акаунта YouTube", acct(lambda: youtube.account_history(s), "Історія акаунта YouTube")),
            mk("Переглянути пізніше", acct(lambda: youtube.watch_later(s), "Переглянути пізніше")),
            mk("Вподобані відео", acct(lambda: youtube.liked(s), "Вподобані відео")),
            mk("Списки відтворення акаунта", acct(lambda: youtube.account_playlists(s), "Списки відтворення акаунта")),
            mk("Чорний список («Не цікавить»)", lambda p: self.open_blocked(p)),
            mk("Еквалайзер (вибір режиму зі списку)", lambda p: self.act_equalizer_menu()),
            mk("Пристрій виводу звуку (вибір зі списку)", lambda p: self.act_audio_device_menu()),
            mk("Папка збережених субтитрів", lambda p: self.act_subs_folder()),
            mk("Закладки цього відео", lambda p: self.act_bookmarks()),
            mk("Розділи відео", lambda p: self.act_chapters_list()),
            mk("Текст відео (субтитри)", lambda p: self.act_transcript()),
            mk("Активація (код активації)", lambda p: self.act_activation()),
            mk("Налаштування", lambda p: self.act_settings()),
            mk("Компоненти (завантажити або перевірити)", lambda p: self.act_components()),
            mk("Клавіші", lambda p: self.act_show_help()),
            mk("Оновити рушій YouTube", lambda p: self.update_engine()),
            mk("Перевірити оновлення програми", lambda p: self.check_app_update()),
            mk("Про програму", lambda p: self.about()),
        ]
        self.you.show_items(items, "Ви")

    def act_resume_last(self):
        if not self.store.get_session():
            self.say("Немає що продовжувати")
        elif not self.offer_resume():
            self.say("Гаразд")

    def open_unfinished(self, panel):
        items = [Item.from_dict(d) for d in self.store.unfinished()]
        for it in items:
            pos = self.store.get_position(it.id)
            it.title = "%s (зупинено на %s)" % (it.title, fmt_time_spoken(pos))
        panel.show_items(items, "Недослухане", push=True)
        if not items:
            self.say("Недослуханого немає")

    def open_blocked(self, panel):
        items = []
        for vid, title in self.store.blocked_videos.items():
            def run(p, v=vid, t=title):
                if wx.MessageBox("Знову показувати відео «%s»?" % t, "Чорний список",
                                 wx.YES_NO | wx.ICON_QUESTION, self) == wx.YES:
                    self.store.unblock_video(v)
                    p.back(silent=True)
                    self.open_blocked(p)
                    self.say("Повернуто")
            items.append(Item(title="Відео: " + (title or vid), kind="menu", extra={"run": run}))
        for name in self.store.blocked_channels:
            def run(p, n=name):
                if wx.MessageBox("Знову рекомендувати канал «%s»?" % n, "Чорний список",
                                 wx.YES_NO | wx.ICON_QUESTION, self) == wx.YES:
                    self.store.unblock_channel(n)
                    p.back(silent=True)
                    self.open_blocked(p)
                    self.say("Повернуто")
            items.append(Item(title="Канал: " + name, kind="menu", extra={"run": run}))
        panel.show_items(items, "Чорний список", push=True)
        if not items:
            self.say("Чорний список порожній")

    def open_history(self, panel, push=True):
        items = [Item.from_dict(d) for d in self.store.history]
        panel.show_items(items, "Історія перегляду", push=push, source=("history",))
        if not items:
            self.say("Історія порожня")

    def open_downloads(self, panel, push=True):
        items = []
        for d in self.store.existing_downloads(self.settings.download_dir):
            items.append(Item(id=d.get("id", ""), title=d.get("title", ""), channel=d.get("channel", ""),
                              duration=int(d.get("duration") or 0), kind="local", path=d["path"]))
        panel.show_items(items, "Завантаження", push=push, source=("downloads",))
        if not items:
            self.say("Завантажень ще немає")

    def open_my_playlists(self, panel):
        items = []
        for name in self.store.playlist_names():
            lst = self.store.playlists.get(name, [])

            def run(p, n=name):
                p.show_items([Item.from_dict(d) for d in self.store.playlists.get(n, [])], n,
                             push=True, source=("playlist", n))

            def delete(n=name, p=panel):
                if wx.MessageBox("Видалити список «%s»?" % n, "Підтвердження",
                                 wx.YES_NO | wx.ICON_WARNING, self) == wx.YES:
                    self.store.delete_playlist(n)
                    p.back(silent=True)
                    self.open_my_playlists(p)
                    self.say("Список видалено")

            items.append(Item(title="%s (%d)" % (name, len(lst)), kind="menu",
                              extra={"run": run, "delete": delete}))
        panel.show_items(items, "Мої списки", push=True)
        if not items:
            self.say("Власних списків ще немає. Додайте відео через контекстне меню.")

    # ---------- налаштування та сервіс ----------
    def act_settings(self):
        dlg = SettingsDialog(self, self.settings, self.keymap, on_update_engine=self.update_engine)
        if dlg.ShowModal() == wx.ID_OK:
            emoji_before = self.settings["emoji_mode"]
            acct_keys = ("cookies_mode", "cookies_browser", "cookies_file")
            acct_before = tuple(self.settings[k] for k in acct_keys)
            dlg.apply()
            self._voices = None
            self._apply_mix()
            self.apply_audio_settings()
            youtube.set_emoji_mode(self.settings["emoji_mode"])
            self.speaker.set_mode(self.settings["speech_mode"])
            self.thumbs.enabled = bool(self.settings["show_thumbnails"])
            self.build_menus()
            self.account.reset()
            for p in self.panels.values():
                p.sync_count()
            self._rebuild_sections()
            self.apply_theme()
            self.refresh_notif_count(False)
            refreshed = False
            if self.settings["emoji_mode"] != emoji_before:
                self.current_panel().refresh()          # перезавантажити список з новим вибором щодо емодзі
                refreshed = True
            if tuple(self.settings[k] for k in acct_keys) != acct_before:
                # акаунт змінився: підписки, сповіщення й рекомендації треба завантажити заново
                self._loaded -= {"subs", "notif", "recs"}
                if self.current_key in ("subs", "notif", "recs") and not refreshed:
                    self._ensure_loaded(self.current_key, focus=False, announce=True)
            self.say("Налаштування збережено")
        else:
            self.keymap = KeyMap(self.settings["keys"])
        dlg.Destroy()

    def act_show_help(self):
        show_help(self, self.keymap)

    def update_engine(self):
        self.say("Оновлюю рушій YouTube. Зачекайте.")

        def work():
            try:
                res = youtube.update_engine()
                msg = "%s Версія %s" % (res, youtube.engine_version())
            except YtError as e:
                msg = str(e)
            wx.CallAfter(self.say, msg)

        threading.Thread(target=work, daemon=True).start()

    # ---------- компоненти (yt-dlp, deno, ffmpeg, libmpv) ----------
    def offer_components(self):
        """На старті: якщо чогось бракує - пропонує завантажити."""
        miss = components.missing()
        if not miss or self._comp_busy:
            return
        names = ", ".join(components.title(k) for k in miss)
        msg = ("Для роботи YouStream потрібно завантажити додаткові компоненти: %s. "
               "Це приблизно %d МБ з інтернету. Завантажити зараз?" % (names, components.size_mb(miss)))
        dlg = wx.MessageDialog(self, msg, "Компоненти", wx.YES_NO | wx.YES_DEFAULT | wx.ICON_QUESTION)
        dlg.SetYesNoLabels("Завантажити", "Пізніше")
        try:
            ans = dlg.ShowModal()
        finally:
            dlg.Destroy()
        if ans == wx.ID_YES:
            self.install_components(miss)
        else:
            self.say("Гаразд. Завантажити їх можна пізніше: вкладка Ви, пункт Компоненти.")

    def act_components(self):
        miss = components.missing()
        if miss:
            self.offer_components()
        elif self.player is None:
            # усе на місці, але аудіодвигун не стартує: перевстановлюємо його разом з vulkan-1.dll
            if wx.MessageBox("Аудіодвигун не запускається. Завантажити його заново? (приблизно %d МБ)"
                             % components.size_mb(["mpv"]), "Компоненти",
                             wx.YES_NO | wx.ICON_QUESTION, self) == wx.YES:
                self.install_components(["mpv"])
        else:
            self.say("Усі компоненти встановлені й працюють.")

    def install_components(self, keys):
        if self._comp_busy:
            self.say("Завантаження вже триває")
            return
        self._comp_busy = True
        self.say("Завантажую компоненти. Це може тривати кілька хвилин. Я розповім про хід.")
        steps = {}

        def progress(key, done, total):
            if not total:
                return
            step = int(done * 100 / total) // 25
            if steps.get(key) != step and step < 4:
                steps[key] = step
                short = components.title(key).split(" (")[0]
                wx.CallAfter(self.say, "%s: %d відсотків" % (short, step * 25), False)

        def work():
            try:
                errors = components.install(keys, progress)
            except Exception as e:  # noqa: BLE001
                log.exception("Встановлення компонентів")
                errors = [str(e)]
            wx.CallAfter(self._components_done, keys, errors)

        threading.Thread(target=work, daemon=True).start()

    def _components_done(self, keys, errors):
        self._comp_busy = False
        if "mpv" in keys and self.player is None:
            self.reload_player()
        if errors:
            self.say("Не все вдалося завантажити. " + " ".join(errors))
        elif self.player is None:
            self.say("Компоненти завантажено, але аудіодвигун не запускається: %s" % self.player_error)
        else:
            self.say("Компоненти встановлено. Можна користуватися.")

    def about(self):
        dev = developer_info()
        wx.MessageBox("%s %s\nКлієнт YouTube для незрячих і зрячих: аудіо й відео.\n\nРозробник: %s\n"
                      "Електронна пошта: %s\n\nРушій yt-dlp: %s\nДані: %s\n"
                      "(Ім'я та пошту можна змінити у файлі data\\developer.json)" % (
                          APP_NAME, APP_VERSION + (" (оновлення %s)" % patching.version() if patching.version() else ""),
                          dev["name"], dev["email"],
                          youtube.engine_version(), self.store.dir),
                      "Про програму", wx.OK, self)

    def on_close(self, e):
        self.timer.Stop()
        try:
            self.downloader.cancel_all()
            if self._sv:
                self._sv.stop()
            self.thumbs.shutdown()
            self.shutdown_playback()
            self.account.cleanup()
            self.settings["keys"] = self.keymap.overrides()
            self.settings.save()
        finally:
            self.Destroy()


def run():
    app = wx.App(False)
    try:                                   # тема Windows (світла/темна), якщо ця збірка wx це вміє
        app.SetAppearance(wx.App.Appearance.System)
    except Exception:  # noqa: BLE001
        pass
    frame = MainFrame()
    frame.Show()
    app.MainLoop()
